---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-03-02T00:00:06Z"
Created by:
    - mammhoud
id: bafyreib7dxopzx4dkmuew2cxu7eldxztduyuxzrd3q6xreiav4vcanlxo4
---
# origin   
[origin](origin.md)    
