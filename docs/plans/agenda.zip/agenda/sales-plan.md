---
# yaml-language-server: $schema=schemas/sales.schema.json
Status: Planned
Object type:
    - Sales
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreigvyj67i3hwz5iexlf5kufdf3lme7o24aejlyecq7bwfu3crqgk6a
---
# Sales Plan   
> Description: Evidence-based route from qualified interest to demo, trial, purchase, onboarding, renewal, and expansion.   

## Sales funnel   
- **Audience** → Lead → Qualified lead → Demo → Trial/Pilot → Proposal   
- **Proposal** → Purchase → Onboarding → Adoption → Renewal/Expansion   
   
## Stage method   
|         Stage   <br> |                                                              Method   <br> |              Exit evidence   <br> |
|:---------------------|:---------------------------------------------------------------------------|:----------------------------------|
|          Lead   <br> |                       Capture source, country, segment, and problem   <br> | Consent and contact record   <br> |
| Qualification   <br> | Confirm branches, terminals, connectivity, integrations, and budget   <br> |   Qualified need and owner   <br> |
|          Demo   <br> |                        Show the workflow for the buyer's restaurant   <br> |           Agreed next step   <br> |
|   Trial/Pilot   <br> |                Run representative orders, KDS, offline, and reports   <br> |              Pilot results   <br> |
|      Proposal   <br> |            Define edition, branch/device limits, support, and price   <br> |  Accepted commercial scope   <br> |
|    Onboarding   <br> |             Configure catalog, staff, printers, taxes, and training   <br> |   First successful service   <br> |
|     Expansion   <br> |                          Measure branch growth and feature adoption   <br> | Renewal or cloud migration   <br> |

## Selling online   
- Product page explains the customer outcome and edition fit.   
- Demo and trial forms capture consent and route to the correct owner.   
- Checkout displays price, taxes, license/renewal terms, support scope, and refund policy clearly.   
- License or subscription fulfillment records product version and entitlements.   
- Post-purchase onboarding links to setup, migration, support, and upgrade paths.   
   
## Sales metrics   
Track qualified leads, demo rate, trial activation, pilot completion, purchase conversion, onboarding time, renewal, support cost, and expansion. Treat targets as hypotheses until baseline data exists.   
## Related   
- → `project-workspace.md` — Workspace hub   
- → `marketing-campaigns.md` — Demand generation   
- → `online-commerce.md` — Online selling   
- → `../products/formint-pos.md` — Product object   
- → `team.md` — Sales ownership   
- → `../../../plans/marketing-claims.md` — Claims evidence   
[Sales Plan](sales-plan.md)    
