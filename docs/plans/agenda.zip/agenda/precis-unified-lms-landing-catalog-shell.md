---
# yaml-language-server: $schema=schemas/cms_editions.schema.json
Object type:
    - CMS Editions
Creation date: "2026-09-09T21:41:38Z"
Created by:
    - mammhoud
id: bafyreidcmsup5wf2hzry7mqgfb4o2s5qv44npbsm4srgpwkochm6nhfeuy
---
# Precis (Unified) — LMS + Landing Catalog Shell   
> Description: The merged Precis product (projects/precis/precis-main/) — LMS courses/enrollment/progress/profile merged with the landing marketing/catalog shell.   

## Scope   
- LMS: courses, enrollment, learning progress, learner profiles, quizzes   
- Landing: marketing pages, catalog shell, intro pages CMS (Wagtail StreamFields)   
- Component library + custom forms   
   
## Boundaries   
- `precis/precis-landing` is a kept legacy copy; runtime identity stays `precis-landing`   
- Do not add new product code under `precis-lms` paths (merged and removed)   
   
## Evidence   
- 🟡 Active (merge in progress)   
- Dispatcher: `WEBSITE=precis-main` (aliases `precis-lms`/`precis-landing` map to it)   
   
## Related   
- → `../features/intro-pages-cms.md` — CMS feature   
- → `../features/learning-curve.md` — Learning experience   
- → `../objects/edition.md` — Edition object type   
[Precis (Unified) — LMS + Landing Catalog Shell](precis-unified-lms-landing-catalog-shell.md)    
