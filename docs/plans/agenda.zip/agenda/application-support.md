---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Backlinks:
    - library.md
Creation date: "2024-07-17T10:49:27Z"
Created by:
    - mammhoud
Links:
    - code.md
    - kiro.md
Emoji: "\U0001F4C2"
id: bafyreihdc6xz2wx2zi3dvd75igstmzwykljtm7gzxyrkbjhfoh6uxywp7i
---
# Application Support   
[Code](code.md)    
[Kiro](kiro.md)    
