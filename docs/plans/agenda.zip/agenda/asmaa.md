---
# yaml-language-server: $schema=schemas/person.schema.json
Status: Active
Role: Developer
Object type:
    - Person
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreie65mqvsq2ymso2pj4fb6n5jq2hi2whzn5mez2g754cfqkow65t6q
---
# Asmaa   
> Developer on the engineering team. Contributes to product development, feature implementation, and code quality.   

## Responsibilities   
- Feature implementation and bug fixes   
- Code review and testing   
- Technical documentation   
   
## Assigned Teams   
- → `../team.md` — Engineering team   
   
## Assigned Tasks   
- → `../task.md` — Active development tasks   
   
## Periodic Tasks   
|                      Task   <br> |   Cadence   <br> |        Team   <br> |
|:---------------------------------|:-----------------|:-------------------|
|   Sprint development work   <br> |    Weekly   <br> | Engineering   <br> |
| Code review participation   <br> |    Weekly   <br> | Engineering   <br> |
|      Bug triage and fixes   <br> |    Weekly   <br> | Engineering   <br> |
|  Technical debt reduction   <br> | Bi-weekly   <br> | Engineering   <br> |
|     Documentation updates   <br> |   Monthly   <br> | Engineering   <br> |

## Related   
- → `../people.md` — Person object type   
- → `../team.md` — Team object   
- → `../../plans/team.md` — Team operating plan   
- → `../../plans/product-development.md` — Development lifecycle   
[Asmaa](asmaa.md)    
