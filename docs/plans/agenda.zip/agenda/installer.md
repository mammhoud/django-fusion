---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2025-07-09T02:18:31Z"
Created by:
    - mammhoud
id: bafyreibal6gh6mt6bu373467gyg4nut77nit3ugpnhcpsanr33oxmbehbu
---
# INSTALLER   
[INSTALLER](installer.md)    
