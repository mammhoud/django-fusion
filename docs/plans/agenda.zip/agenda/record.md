---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2025-10-05T23:19:05Z"
Created by:
    - mammhoud
id: bafyreiciyjqgra6kmlbb3d47egbzdo2ys4dioxi7zpqj57mqwzrapgm7nu
---
# RECORD   
[RECORD](record.md)    
