---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-08-07T23:17:24Z"
Created by:
    - mammhoud
id: bafyreihvzvfdiavmqyq3ppmfmdukrx4ygzlct5k3lh23lrgd6nyld6bv2m
---
# property-information   
[property-information](property-information.md)    
