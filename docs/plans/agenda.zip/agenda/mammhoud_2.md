---
# yaml-language-server: $schema=schemas/person.schema.json
Status: Active
Role: Founder
Object type:
    - Person
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreihviaptc6favd26qzimak6h2rjtihs42eqn3jf5x5kkgc72hqflru
---
# Mammhoud   
> Founder and owner of all Structa Cloud products. Coordinates architecture decisions, product direction, and team leadership.   

## Responsibilities   
- Architecture decisions and technical direction   
- Product strategy and roadmap ownership   
- Team coordination and sprint oversight   
- Code review and quality gates   
   
## Owned Products   
- → `../../products/formint-pos.md` — Formint POS   
- → `../../products/\_index.md` — Product portfolio   
   
## Made Decisions   
- → `../../decisions/001-monorepo-django-wagtail.md` — Monorepo architecture   
- → `../../decisions/002-django-fusion-component-system.md` — Component system   
- → `../../decisions/003-tauri-rust-desktop-pos.md` — Desktop POS   
   
## Authored Posts   
- → `../../blog/\_index.md` — Blog index   
   
## Periodic Tasks   
|                         Task   <br> |   Cadence   <br> |        Team   <br> |
|:------------------------------------|:-----------------|:-------------------|
|       Sprint planning review   <br> |    Weekly   <br> |     Product   <br> |
| Architecture decision review   <br> | Bi-weekly   <br> | Engineering   <br> |
|       Product roadmap update   <br> |   Monthly   <br> |     Product   <br> |
|          Team capacity check   <br> | Bi-weekly   <br> |  Management   <br> |

## Related   
- → `../people.md` — Person object type   
- → `../team.md` — Team object   
- → `../../plans/team.md` — Team operating plan   
[Mammhoud](mammhoud_2.md)    
