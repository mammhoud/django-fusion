---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: In Development
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreifspisqdw37isapwgbqmkzzowget5hcnirlhseybanlwek6egsski
---
# SOLO Version — Standalone POS Edition   
> Type: Workspace 🏢   
> Emoji: 🎋   
> Description: The standalone, single-branch POS edition — full desktop application with LAN sync and embedded Python sidecar.   

> Legacy: Archived with the deprecated version labels (pos-mini / pos-solo / pos-full). See ../../architecture/editions.md for current edition scope.   

 --- 
## Overview   
POS Solo is the middle-tier edition bridging Mini and Full:   
|         Aspect   <br> |                                                                           Detail   <br> |
|:----------------------|:----------------------------------------------------------------------------------------|
|   **Platform**   <br> |                                         Desktop (Tauri) + Sidecar (Python/Robyn)   <br> |
|   **Database**   <br> |                                                                   SQLite (local)   <br> |
|       **Sync**   <br> |                                          LAN — branch devices poll master server   <br> |
| **Tech Stack**   <br> |     Rust (Tauri shell) → TypeScript (React UI) → Python (Django ORM + Robyn API)   <br> |

 --- 
## Architecture Breakdown   
### Rust Layer   
Tauri desktop shell — window management, native file dialogs, system tray, and bridging to TypeScript frontend via Tauri commands.   
### Python Sidecar (Django ORM + Robyn API)   
Business logic layer — Django models for POS entities (Product, Sale, Employee), Robyn HTTP server exposing REST endpoints at port 8766. Handles all data persistence and LAN sync.   
### TypeScript Frontend (React + Tauri)   
UI layer built with React 19, connected to the sidecar via HTTP and to Tauri via `@tauri-apps/api`. State management via Redux, styling via Tailwind CSS v4 with theme system.   
 --- 
## Project Context   
|        Aspect   <br> |                                                                                                    Description   <br> |
|:---------------------|:----------------------------------------------------------------------------------------------------------------------|
|  **Repopath**   <br> |                                                                                       `projects/pos/pos-solo/`   <br> |
|     **Color**   <br> |   Django Green (#0c4a6e deep teal) / Python Blue (#306998) — representing the Python/Django backend foundation   <br> |
|     **Ports**   <br> |                                                                                 Sidecar: 8766, Tauri dev: 1420   <br> |
| **Key Files**   <br> |                                                     `sidecar/server.py`, `src/App.tsx`, `src-tauri/src/lib.rs`   <br> |

 --- 
## Color Palette: Solo Teal   
|       Token   <br> |                   Hex   <br> |                         Usage   <br> |
|:-------------------|:-----------------------------|:-------------------------------------|
|     Primary   <br> |  `#0d9488` (Teal-600)   <br> |  Solo branding, active states   <br> |
|     Surface   <br> | `#f0fdfa` / `#134e4a`   <br> | Dashboard panels (light/dark)   <br> |
|      Accent   <br> |  `#14b8a6` (Teal-500)   <br> |     Sidecar status indicators   <br> |
| Python Blue   <br> |             `#306998`   <br> |          Python/sidecar badge   <br> |
| Rust Orange   <br> |             `#dea584`   <br> |              Rust/Tauri badge   <br> |

 --- 
## Related Docs   
- → `free-version.md` — Free community version   
- → `full-version.md` — Enterprise version   
- → `../../architecture/editions.md` — Current editions   
- → `../../architecture/editions.md` — Edition comparison   
- → `../../guides/\_index.md` — Guides index   
- → `../../README.md` — Master index   
[SOLO Version — Standalone POS Edition](solo-version-standalone-pos-edition.md)    
