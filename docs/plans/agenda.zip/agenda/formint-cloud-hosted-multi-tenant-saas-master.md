---
# yaml-language-server: $schema=schemas/pos_edition.schema.json
Status: In Development
Object type:
    - POS Edition
Created by:
    - mammhoud
Creation date: "2026-09-09T21:41:38Z"
id: bafyreigufmr7wbfzhrcvpz3h5jgb6gaepkg7q5vyjnhqopgl6v4cqvb6xu
---
# Formint Cloud — Hosted Multi-Tenant SaaS Master   
> Description: The cloud-hosted SaaS control plane (projects/formints/formint-cloud/) — schema-per-tenant master serving the API from Django (the Robyn sidecar is retired).   

## Scope   
- Hosted multi-tenant SaaS master (apps/core + apps/domain + apps/handlers, Channels ASGI)   
- Automatic backups (`BackupRun` model + `backup\_db` management command)   
- Monitoring (`/monitor/status` endpoint)   
- Cross-branch transport and analytics, billing, managed integrations   
- Tenant schemas (Postgres flip-on pending)   
   
## Boundaries   
- Cloud is the schema-per-tenant master; Community/Standard/Pro are offline-capable editions   
- Cloud API serves from Django on the canonical formint-cloud path   
   
## Evidence   
- 🟡 Staging (per d`ocs/plans/editions/ `chain status)   
- Tenant schemas: 🟡 Postgres flip-on pending   
- Plan: `../../../plans/editions/04-cloud.md`   
   
## Related   
- → `formint-pro.md` — Base tier   
- → `../plans/cloud.md` — Cloud operating model   
- → `../objects/edition.md` — Edition object type   
[Formint Cloud — Hosted Multi-Tenant SaaS Master](formint-cloud-hosted-multi-tenant-saas-master.md)    
