---
# yaml-language-server: $schema=schemas/story.schema.json
Status: Published
Object type:
    - Story
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreigsnq6lxrxk2mowld3dca2uojxbtgvstkanusyr3dy26ooit23v6y
---
# Starting the Project — The Founder's Journey   
> Description: The story of how the Structa Cloud project and mono repository began — from a first Django experiment through small sites, scalability learnings, an AI-driven component stack, the django-fusion package, and finally a desktop + cloud platform.   

 --- 
## Preface   
Every large platform starts with a single experiment. This is the record of how this project started, the technologies explored, the lessons learned about scalability, and how a personal learning journey grew into a component system, a CMS-driven platform, and a desktop-plus-cloud product suite. It is told as a story with clear phases so it can be read as a narrative, tracked as achievements, and linked back to goals and plans.   
 --- 
## Phase 1 — Foundations: learning Django by building small sites   
The project began by learning **Django**. Rather than studying in isolation, the approach was to build real, small sites immediately.   
**What happened:**   
|            Step   <br> |                                                                                       Detail   <br> |
|:-----------------------|:----------------------------------------------------------------------------------------------------|
| First framework   <br> |                                                                   Django as the core backend   <br> |
|  First products   <br> |                                                        Small websites implemented end-to-end   <br> |
| Learning method   <br> | Build-first; each small site deepened understanding of routing, models, views, and templates   <br> |

**Lesson:** The fastest way to learn a framework is to ship small, working sites. This built the confidence and foundation that later scaled into a full platform.   
 --- 
## Phase 2 — Experimentation: exploring the frontend and live data   
Next the focus turned to the frontend and real-time behavior, experimenting with the surrounding JavaScript and server-sent event stack.   
**What happened:**   
| Technology / idea   <br> |                                  What was explored   <br> |
|:-------------------------|:----------------------------------------------------------|
|          **htmx**   <br> | Server-driven interactions with minimal JavaScript   <br> |
|     **Alpine.js**   <br> |                 Lightweight client-side reactivity   <br> |
|    **WebSockets**   <br> |                Small live apps built and completed   <br> |

**Lessons:**   
- htmx and Alpine.js keep the frontend simple by pushing logic to the server and sprinkling lightweight interactivity.   
- WebSocket apps taught the fundamentals of real-time communication and led to later support for server-sent events (SSE).   
   
**Outcome:** Several small WebSocket-based apps were completed, and the team gained a working feel for building interactive, live applications.   
 --- 
## Phase 3 — Foundations of scalability and multi-tenancy   
This phase moved from "make it work" to "make it scale." The focus was on what actually makes an application scalable, especially at the database layer.   
**What happened:**   
|                    Topic   <br> |                                                                             What was learned   <br> |
|:--------------------------------|:----------------------------------------------------------------------------------------------------|
| Scalable database design   <br> |                            How databases behave under growth, and what makes an app scalable   <br> |
|            Multi-tenancy   <br> | Adding multiple tenants at the database level so one deployment serves many customers safely   <br> |
|           Authentication   <br> |                User registration and login with **OAuth** and the **django-allauth** package   <br> |

**Lessons:**   
- Scalability is largely decided early, by how data is modeled and how tenants are isolated.   
- Multi-tenant databases let one platform serve many customers with shared infrastructure.   
- Authentication is a solved problem in Django — standard packages like allauth cover registration and OAuth cleanly.   
   
**Outcome:** A clear mental and technical model of how a shared platform can host many customers, which later informed the SaaS and cloud editions.   
 --- 
## Phase 4 — The backend, APIs, AI, and agentic development   
The backend became more than a plain web application. Django grew into an integrated backend that served APIs, connected to newly developed packages, and adopted AI and agentic workflows.   
**What happened:**   
|               Focus   <br> |                                            Detail   <br> |
|:---------------------------|:---------------------------------------------------------|
|   Django as backend   <br> |            Central backend serving data and logic   <br> |
|        API packages   <br> |     Integration with newly developed API packages   <br> |
|            AI stack   <br> |              Introduction of AI-assisted features   <br> |
| Agentic development   <br> | Agents and MCP (Model Context Protocol) workflows   <br> |

**Outcome:** The backend became an API-powered, AI-capable service — the bridge between the data layer and increasingly intelligent product features.   
 --- 
## Phase 5 — First products: LMS, websites, and CRM   
With the foundation in place, the first real products were built, one after another.   
**What happened:**   
|                  Product   <br> |                                              What was built   <br> |
|:--------------------------------|:-------------------------------------------------------------------|
|            **Small LMS**   <br> |                          A first learning management system   <br> |
|        **Website pages**   <br> |                             Marketing and company web pages   <br> |
| **CRM with admin panel**   <br> |                        A CRM backed by a Django admin panel   <br> |
|             **Full CRM**   <br> | Complete CRM backend with a full frontend and custom themes   <br> |
|         **Complete LMS**   <br> |                  A full LMS with complete user registration   <br> |
|         **Agents + MCP**   <br> |                                Agent workflows added on top   <br> |

**Lesson:** A shared backend pattern (Django) let each product reuse the same skills, auth, and data approach, so building each successive product got faster.   
 --- 
## Phase 6 — django-fusion: the component system   
The biggest turning point was the creation of **django-fusion**, a package that wraps components and makes building anything faster and more consistent.   
**What it does:**   
|                  Capability   <br> |                                                                              Detail   <br> |
|:-----------------------------------|:-------------------------------------------------------------------------------------------|
|            Component system   <br> |                              Reusable building-block components across the platform   <br> |
|   Easier component requests   <br> |                           Components can be requested/rendered simply and uniformly   <br> |
|      Rich component content   <br> | A component can contain data, a table, an htmx request, or server-sent events (SSE)   <br> |
| Backend/frontend separation   <br> |                 A component can be added to a project split as backend and frontend   <br> |
|       Reuse across products   <br> |                 Used to build POS and LMS completely, and the company website pages   <br> |

**Impact:** django-fusion became the shared layer that made every subsequent product faster to build and easier to maintain.   
 --- 
## Phase 7 — CMS-driven sites and an AI-enabled fast dev cycle   
The final product-level step was making every website content-driven and adaptive with AI.   
**What happened:**   
|                 Capability   <br> |                                                                Detail   <br> |
|:----------------------------------|:-----------------------------------------------------------------------------|
|         **Wagtail as CMS**   <br> | Wagtail integrated as the content management system into each website   <br> |
|       **Per-page content**   <br> |                         Every page has manageable, structured content   <br> |
|            **Flexible AI**   <br> |          AI can change a component, its fields, data flow, and design   <br> |
| **Fast development cycle**   <br> |                    AI-assisted editing makes iterating on pages quick   <br> |

**Outcome:** The platform became a CMS-driven, AI-flexible system where design, content, and data flow can be adapted quickly — the foundation of a fast development cycle for the whole company.   
 --- 
## Phase 8 — Desktop, cloud, and platform engineering   
The last phase turned the web platform into a full product suite with desktop and cloud presence.   
**What happened:**   
|                             Focus   <br> |                                                                              Detail   <br> |
|:-----------------------------------------|:-------------------------------------------------------------------------------------------|
|                     **POS Suite**   <br> |                                           The POS extended to a desktop application   <br> |
|                         **Tauri**   <br> |                                                        Desktop app built with Tauri   <br> |
|                         **Cloud**   <br> |                                                  POS integrated with cloud services   <br> |
|              **Frontend project**   <br> |                    A dedicated frontend project with a familiar, related tech stack   <br> |
|                 **Documentation**   <br> |                                         Full documentation written for the projects   <br> |
| **Workspace development (Coder)**   <br> | The workspace is developed and hosted on the server as a coding workspace via Coder   <br> |

**Outcome:** The project is now a platform — web, desktop, and cloud — with reusable components, AI flexibility, documentation, and a server-hosted development workspace.   
 --- 
## Phase 9 — Forge → Formint: The Great Rename   
The journey from Forge to Formint was not just a name change — it was a strategic pivot from a temporary development label to a permanent product identity.   
**What happened:**   
|                            Step   <br> |                                                                                       Detail   <br> |
|:---------------------------------------|:----------------------------------------------------------------------------------------------------|
|  **Forge as development speed**   <br> |   Used `pos-mini`, `pos-solo`, `pos-full` as internal labels to move fast during development   <br> |
|     **Forge as feature source**   <br> |       Built features under Forge labels, testing ideas quickly without worrying about naming   <br> |
| **Formint as product identity**   <br> | When the product vision crystallized, created Formint as the permanent customer-facing brand   <br> |
|          **Migration strategy**   <br> |            Developed a controlled transfer from Forge capabilities into Formint Professional   <br> |
|         **Old names for speed**   <br> |    Kept old names in development for fast iteration, changed to new names for public release   <br> |
|            **Open for opinion**   <br> |           Made the naming decision open for team input before finalizing the public identity   <br> |

**Development approach:**   
|              Phase   <br> |                          Name Used   <br> |                              Purpose   <br> |
|:--------------------------|:------------------------------------------|:--------------------------------------------|
|  Early development   <br> | `pos-mini`, `pos-solo`, `pos-full`   <br> | Fast prototyping, no naming pressure   <br> |
|   Feature building   <br> |                       Forge labels   <br> | Quick iteration, feature experiments   <br> |
| Product definition   <br> |                            Formint   <br> |  Permanent identity, customer-facing   <br> |
|     Public release   <br> |    Formint Professional, POS Cloud   <br> |                  Market-ready naming   <br> |

**Lessons:**   
- Using temporary names during development enables speed — you don't waste time on branding before the product vision is clear.   
- The rename from Forge to Formint was a strategic decision, not just cosmetic — it signaled the shift from experiment to product.   
- Making naming decisions open for team input builds ownership and ensures the name resonates with everyone.   
- Old names stay in development context; new names are for the public.   
   
**Outcome:** The product now has a clear, permanent identity (Formint) while the development process used temporary names (Forge) to maintain velocity. The migration was controlled, documented, and open for team input.   
 --- 
## Phase 10 — Publishing the journey   
With the product identity established, the focus shifted to sharing the story and inviting community input.   
**What happened:**   
|                     Step   <br> |                                                Detail   <br> |
|:--------------------------------|:-------------------------------------------------------------|
|  **Story documentation**   <br> |              Wrote the founder journey as a narrative   <br> |
| **Achievement tracking**   <br> |        Linked phases to goals and measurable outcomes   <br> |
|     **Open for opinion**   <br> | Made the story and naming open for community feedback   <br> |
|  **Publishing decision**   <br> |     Decided what to publish and what to keep internal   <br> |

**Publishing principles:**   
- Share the journey, not just the destination   
- Be open about decisions and invite input   
- Keep internal development details separate from public narrative   
- Let the community shape the final presentation   
   
**Outcome:** The story is now a living document that invites participation while maintaining a clear narrative arc from experiment to platform.   
 --- 
## Timeline summary   
| Phase   <br> |             Theme   <br> |                                          Key outcome   <br> |
|:-------------|:-------------------------|:------------------------------------------------------------|
|     1   <br> |       Foundations   <br> |                     Django skills; first small sites   <br> |
|     2   <br> |   Experimentation   <br> |                 htmx, Alpine.js, WebSockets explored   <br> |
|     3   <br> |       Scalability   <br> |                         Multi-tenancy, OAuth/allauth   <br> |
|     4   <br> |      Backend & AI   <br> |                          APIs, AI stack, agents, MCP   <br> |
|     5   <br> |    First products   <br> |                                   LMS, websites, CRM   <br> |
|     6   <br> |     django-fusion   <br> |                              Shared component system   <br> |
|     7   <br> |          CMS & AI   <br> |                      Wagtail + flexible AI dev cycle   <br> |
|     8   <br> |          Platform   <br> | Tauri desktop, cloud, documentation, Coder workspace   <br> |
|     9   <br> |   Forge → Formint   <br> |       Great rename, controlled migration, open input   <br> |
|    10   <br> |        Publishing   <br> |                 Story documentation, community input   <br> |

 --- 
## What this means now   
The mono repository is the unified home of all these experiments, products, and packages. Every phase — from a single Django experiment to a desktop-and-cloud platform — lives in one repository, documented and traceable back to the goals and achievements on the board.   
 --- 
## Related   
- → `../goals/achievement-board.md` — Phase-by-phase achievement tracker   
- → `./notes/start-up-journal.md` — Raw working notes   
- → `../plans/startup-planner.md` — Product and business strategy   
- → `../plans/product-development.md` — Development lifecycle   
- → `../plans/project-workspace.md` — Portfolio workspace   
- → `../products/formint-pos.md` — POS product description   
- → `../objects/story.md` — Story object type   
- → `../README.md` — Anytype hub   
[Starting the Project — The Founder&#39;s Journey](starting-the-project-the-founders-journey.md)    
