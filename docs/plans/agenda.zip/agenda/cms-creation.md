---
# yaml-language-server: $schema=schemas/feature.schema.json
Object type:
    - Feature
Status: Published
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreidrrxd43oewpqozl4eghjos4lhh4rni5k4ustpkkuxknerkgr2vvi
---
# CMS Creation   
> Type: Workspace 🏢   
> Platform: LMS Demo site (structa.cloud) — introductory content pages for the learning management system.   

 --- 
## Overview   
Intro Pages form the welcoming face of the LMS Demo site. They include:   
- **Home page** — Hero section, featured courses, call-to-action   
- **About page** — Platform mission, team, and value proposition   
- **Contact page** — Inquiry form, location, support channels   
- **FAQ page** — Frequently asked questions and answers   
- **Terms & Privacy** — Legal pages managed through Wagtail   
 --- 
   
## Project Context   
|         Aspect   <br> |                                                                       Description   <br> |
|:----------------------|:-----------------------------------------------------------------------------------------|
|   **Repopath**   <br> |                                                                   `projects/lms/`   <br> |
|       **Site**   <br> |                                                         structa.cloud (port 5071)   <br> |
|      **Color**   <br> |   Emerald (#10b981) / Teal (#14b8a6) — representing learning growth and education   <br> |
| **CMS Engine**   <br> |                                 Wagtail Page models with django-fusion components   <br> |
|  **Templates**   <br> |                                          Shared from `projects/assets/templates/`   <br> |

 --- 
## Color Palette: LMS Emerald   
|     Token   <br> |                     Hex   <br> |                                    Usage   <br> |
|:-----------------|:-------------------------------|:------------------------------------------------|
|   Primary   <br> | `#10b981` (Emerald-500)   <br> | CTA buttons, course cards, progress bars   <br> |
|   Surface   <br> |   `#ecfdf5` / `#064e3b`   <br> |            Page backgrounds (light/dark)   <br> |
|    Accent   <br> |    `#14b8a6` (Teal-500)   <br> |           Links, section headers, badges   <br> |
| Highlight   <br> | `#34d399` (Emerald-400)   <br> |       Success states, completion markers   <br> |

 --- 
## Wagtail Content Models   
|     Page Type   <br> |             Template   <br> |                              Purpose   <br> |
|:---------------------|:----------------------------|:--------------------------------------------|
|    `HomePage`   <br> |    `pages/home.html`   <br> | Hero, features grid, course previews   <br> |
|   `AboutPage`   <br> |   `pages/about.html`   <br> |        Mission, team, platform story   <br> |
| `ContactPage`   <br> | `pages/contact.html`   <br> |             Contact form, map, hours   <br> |
|     `FaqPage`   <br> |     `pages/faq.html`   <br> |                Accordion FAQ, search   <br> |
| `PrivacyPage`   <br> | `pages/privacy.html`   <br> |           Legal content, data policy   <br> |

 --- 
## Related Docs   
- → `../architecture/website-descriptions.md` — LMS site details   
- → `../references/\_index.md` — Content models schema (planned)   
- → `quizzes.md` — LMS quiz features   
- → `learning-curve.md` — Learning progression design   
- → `../guides/\_index.md` — Quick start   
- → `../README.md` — Master index   
[CMS Creation](cms-creation.md)    
