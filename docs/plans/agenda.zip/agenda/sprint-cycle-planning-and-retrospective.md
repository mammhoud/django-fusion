---
# yaml-language-server: $schema=schemas/sprint.schema.json
Status: Published
Object type:
    - Sprint
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreifeoqtczt5nllwekax2egw6gqsihpzi2mzdeiiepavkryyol5k3wu
---
# Sprint — Cycle Planning & Retrospective   
> Type: Sprint 🏃   
> Layout: Page   
> Description: Sprint cycles — planning, execution, review, and retrospective tracking across team workflows.   

 --- 
## Properties   
|             Property   <br> |                   Type   <br> |                                Options   <br> |          Description   <br> |
|:----------------------------|:------------------------------|:----------------------------------------------|:----------------------------|
|             `Status`   <br> |                 Select   <br> | Planning, Active, Completed, Cancelled   <br> |         Sprint phase   <br> |
|      `Sprint Number`   <br> |                 Number   <br> |                                      —   <br> |    Sprint identifier   <br> |
|         `Start Date`   <br> |                   Date   <br> |                                      —   <br> |         Sprint start   <br> |
|           `End Date`   <br> |                   Date   <br> |                                      —   <br> |           Sprint end   <br> |
|              `Goals`   <br> |      Text (multi-line)   <br> |                                      —   <br> |    Sprint objectives   <br> |
|      `Retrospective`   <br> |      Text (multi-line)   <br> |                                      —   <br> |      Lessons learned   <br> |
|              `Owner`   <br> |      Relation → Person   <br> |                                      —   <br> |   Scrum master/owner   <br> |
|      `Related Tasks`   <br> |        Relation → Task   <br> |                                      —   <br> | Tasks in this sprint   <br> |
|      `Related Goals`   <br> |        Relation → Goal   <br> |                                      —   <br> |         Sprint goals   <br> |
| `Related Milestones`   <br> |   Relation → Milestone   <br> |                                      —   <br> |   Related milestones   <br> |
|               `Tags`   <br> |           Multi-select   <br> |                                      —   <br> | Cross-cutting labels   <br> |

 --- 
## Usage   
Sprint contains Tasks, which achieve Goals and target Milestones.   
| Relation   <br> |    Target   <br> |
|:----------------|:-----------------|
| contains   <br> |      Task   <br> |
| achieves   <br> |      Goal   <br> |
|  targets   <br> | Milestone   <br> |

 --- 
## Related   
- → `\_object-types.md` — All type definitions   
- → `task.md` — Task entity   
- → `goal.md` — Goal entity   
- → `milestone.md` — Milestone entity   
- → `people.md` — Person/Owner entity   
[Sprint — Cycle Planning &amp; Retrospective](sprint-cycle-planning-and-retrospective.md)    
