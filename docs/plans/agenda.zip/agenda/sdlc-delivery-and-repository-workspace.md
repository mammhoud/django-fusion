---
# yaml-language-server: $schema=schemas/workspace.schema.json
Status: Active
Object type:
    - Workspace
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreiewli2fnvjmu5b265q4dhkc3zfspq2s3qalmuli3xqrnfytvhc5wi
---
# SDLC — Delivery & Repository Workspace   
> Description: Navigation hub for Structa Cloud sites, libraries, infrastructure, and the current Formint product workspace. Combines directory navigation with detailed site and application references.   
> Paths normalized 2026-09-10 to the current tree (see repo AGENTS.md migration rules).   

## Current web and platform projects   
|              Project   <br> |                                        Path   <br> |                                     Purpose   <br> |                                                 Responsibility   <br> |            Status   <br> |
|:----------------------------|:---------------------------------------------------|:---------------------------------------------------|:----------------------------------------------------------------------|:-------------------------|
|     Precis (unified)   <br> |              `projects/precis/precis-main/`   <br> |            LMS + marketing catalog (merged)   <br> |                    Courses, enrollment, progress, catalog, SEO   <br> |            Active   <br> |
|         CTC Research   <br> |               `projects/precis/precis-ctc/`   <br> |                  Research and training site   <br> |                    Research publication and training workflows   <br> |            Active   <br> |
| Syntara (Cypercloud)   <br> |                         `projects/syntara/`   <br> |              AI chat customization platform   <br> |                  AI chat customization and model configuration   <br> |    In Development   <br> |
|             Loop-CRM   <br> |                        `projects/loop-crm/`   <br> |                     CRM + social scheduling   <br> |                          Pipelines, campaigns, finance, AI hub   <br> |            Active   <br> |
|          Formint POS   <br> |                        `projects/formints/`   <br> |            Restaurant POS product workspace   <br> |                        Restaurant operations product workspace   <br> |    In Development   <br> |
|        django-fusion   <br> |                       `libs/django-fusion/`   <br> | Shared Django component and routing library   <br> | Component routing, generic views, forms, tables, and fragments   <br> |            Active   <br> |
|            ceptor-ai   <br> | `libs/ceptor-ai/` (submodule, pending init)   <br> |                   AI client and MCP tooling   <br> |                  AI client, MCP server, and generation helpers   <br> | Active (external)   <br> |

> Retired paths — projects/lms (merged into precis-main), projects/portfolio   
> (VResume, not pursued), projects/tinker (superseded by Syntara),   
> projects/pos (now projects/formints/), projects/cypercloud (now   
> projects/syntara/), projects/ctc-research (now under projects/precis/).   
> Git history is the archive.   

## Formint POS workspace   
Restaurant operations product workspace containing the current desktop/application work and the path toward managed cloud services.   
- **Product model:** Community, Formint Professional, POS Cloud   
- **Professional boundary:** offline-capable local operations, restaurant workflows, KDS, catalog, inventory, reports, and integrations as released   
- **Cloud boundary:** hosted tenants, branch coordination, analytics, billing, backups, and managed integrations   
- **Status:** In Development   
   
### POS product labels   
The current customer-facing model is:   
- **Community** — free/self-hosted core POS   
- **Formint Professional** — offline-capable restaurant operations and premium workflows   
- **POS Cloud** — hosted branches, analytics, billing, backups, and managed services   
   
`pos-mini`, `pos-solo`, `pos-full`, and Forge are implementation or migration labels. Keep them in migration and historical objects only; do not use them as current product editions.   
## Infrastructure projects   
| Component   <br> |                      Path   <br> |                 Responsibility   <br> |
|:-----------------|:---------------------------------|:--------------------------------------|
|     Proxy   <br> |     `applications/proxy/`   <br> | TLS, routing, and certificates   <br> |
| Databases   <br> | `applications/databases/`   <br> |           PostgreSQL and Redis   <br> |
|   Compose   <br> |   `applications/compose/`   <br> |          Service orchestration   <br> |

## Use   
Use this page for navigation, not for detailed product or implementation claims. Link a project to its Product, Plans, Teams, and evidence objects. Update status when repository ownership or delivery state changes.   
## Related   
- → `project-workspace.md` — Portfolio planning hub   
- → `product-development.md` — Product lifecycle   
- → `../products/formint-pos.md` — Formint product   
- → `../objects/\_status.md` — Anytype lifecycle status   
- → `../README.md` — Anytype hub   
