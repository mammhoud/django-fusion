---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2019-06-07T19:36:35Z"
Created by:
    - mammhoud
id: bafyreigtkmpcurabxclgmaa3hfu47csglnlhg2jytmquiuobmhjuwv5jwm
---
# Colors   
[Colors](colors.md)    
