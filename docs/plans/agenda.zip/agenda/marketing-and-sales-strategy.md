---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Active
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreicmcru4avtd7k54tn2eq7tcswy5bgr45y5c7di7i4ule2jzfguy3u
---
# Marketing & Sales Strategy   
> Description: Integrated go-to-market system connecting product positioning, campaigns, social networks, online selling, sales qualification, onboarding, and customer feedback.   

## Core funnel   
- **Research** → Positioning → Campaign → Lead → Demo/Trial → Sale   
- **Sale** → Onboarding → Adoption → Renewal/Expansion → Referral   
   
## Audience and message   
|            Audience   <br> |                                 Problem   <br> |                                       Message direction   <br> |                           Proof   <br> |
|:---------------------------|:-----------------------------------------------|:---------------------------------------------------------------|:---------------------------------------|
|     Small operators   <br> |          Cost, complexity, connectivity   <br> |                          Useful core with local control   <br> | Install and first-sale evidence   <br> |
| Growing restaurants   <br> | Branch, kitchen, inventory coordination   <br> | Formint connects local continuity with restaurant depth   <br> |         Pilot workflow evidence   <br> |
|   Chains/franchises   <br> |              Visibility, control, scale   <br> |     POS Cloud coordinates branches and managed services   <br> |     Branch and restore evidence   <br> |
| Developers/partners   <br> |           Extensibility and integration   <br> |                     Versioned APIs and clear boundaries   <br> |        API contract and sandbox   <br> |

## Channel system   
- **Website and product pages** — Explain the product and capture intent   
- **Content and social** — Teach workflows and build trust   
- **Demo/trial** — Prove the relevant outcome   
- **Online checkout** — Make terms, price, support, and entitlement clear   
- **Sales** — Qualify, pilot, propose, onboard, and expand   
- **Community/support** — Collect evidence and return it to product development   
   
## Campaign portfolio   
Use `marketing-campaigns.md` for individual campaign briefs. Recommended Formint campaigns are offline continuity, kitchen clarity, Arabic-first operations, restaurant depth, and local-to-cloud growth.   
## Measurement   
Measure qualified leads, demo completion, trial activation, pilot outcomes, purchase conversion, onboarding time, retention, expansion, support cost, and claim evidence. Do not publish targets as achievements until measured.   
## Responsible tone   
Use specific customer benefits and release status. Avoid "best," "market leader," "fully compliant," guaranteed uptime, or numerical performance claims without approved evidence.   
## Periodic marketing tasks   
|                         Task   <br> |   Cadence   <br> |         Team   <br> |
|:------------------------------------|:-----------------|:--------------------|
|  Campaign performance review   <br> |    Weekly   <br> |    Marketing   <br> |
|         Lead pipeline review   <br> |    Weekly   <br> |        Sales   <br> |
|      Content calendar update   <br> | Bi-weekly   <br> |    Marketing   <br> |
|   Competitive landscape scan   <br> |   Monthly   <br> |    Marketing   <br> |
|         Claim evidence audit   <br> | Quarterly   <br> | Data Analyst   <br> |
| Go-to-market strategy review   <br> | Quarterly   <br> |      Product   <br> |

## Related   
- → `project-workspace.md` — Portfolio hub   
- → `marketing-campaigns.md` — Campaign plans   
- → `sales.md` — Sales plan   
- → `online-commerce.md` — Online selling   
- → `social-networks.md` — Social channels   
- → `../products/formint-pos.md` — Product description   
- → `pos-market-research.md` — POS market evidence   
