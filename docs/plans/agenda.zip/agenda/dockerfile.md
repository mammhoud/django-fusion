---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-07-23T18:03:27Z"
Created by:
    - mammhoud
id: bafyreialoz5awwri6pl5mizc72qmb7fgalrj32ayaklwrnazbykzv6nqte
---
# Dockerfile   
[Dockerfile](dockerfile.md)    
