---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-09-16T22:13:51Z"
Created by:
    - mammhoud
id: bafyreic3pstueuovmo4dp44u6wga4i7pung7aeag2r76ixk6aq76dqybwi
---
# \_ruleset3   
[\_ruleset3](ruleset3.md)    
