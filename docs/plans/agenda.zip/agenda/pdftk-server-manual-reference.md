---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-06-29T17:55:41Z"
Created by:
    - mammhoud
id: bafyreihak4jjf45zejkyhlalkjuzhtpsj7i4rzsnxpxw72vok5mopjrnfe
---
# PDFtk Server Manual Reference   
- **`pdftk` version 2.02**   
- Check [version history](https://www.pdflabs.com/docs/pdftk-version-history/) for changes   
- See [server manual](https://www.pdflabs.com/docs/pdftk-man-page/) for the latest documentation   
   
## Overview   
PDFtk is a command-line utility for manipulating PDF documents. It enables operations including merging, splitting, rotating, encrypting, decrypting, watermarking, form-filling, and metadata extraction of PDF files.   
## Synopsis   
```
pdftk [input PDF files | - | PROMPT]
      [input_pw <passwords>]
      [<operation>] [<operation arguments>]
      [output <filename | - | PROMPT>]
      [encrypt_40bit | encrypt_128bit]
      [allow <permissions>]
      [owner_pw <password>] [user_pw <password>]
      [compress | uncompress]
      [flatten] [need_appearances]
      [verbose] [dont_ask | do_ask]

```
## Input Options   
**Input PDF Files**: Specify one or more PDFs. Use `-` for stdin or `PROMPT` for interactive input. Files may be assigned handles (single uppercase letters) for reference in operations:   
```
pdftk A=file1.pdf B=file2.pdf cat A B output merged.pdf

```
**Input Passwords** (`input\_pw`): For encrypted PDFs, provide owner or user passwords associated with file handles or by input order:   
```
pdftk A=secured.pdf input_pw A=foopass cat output unsecured.pdf

```
## Core Operations   
### cat - Concatenate and Compose   
Merge, split, or reorder pages with optional rotation. Supports page ranges, reverse ordering (prefix `r`), page qualifiers (`even`/`odd`), and rotation (compass directions `north`, `south`, `east`, `west`, `left`, `right`, `down`).   
Page range syntax: `[handle][begin[-end[qualifier]]][rotation]`   
```
pdftk A=in1.pdf B=in2.pdf cat A1-7 B1-5 A8 output combined.pdf

```
### shuffle - Collate Pages   
Takes one page from each input range in turn, producing an interleaved result. Useful for collating separately scanned odd and even pages.   
```
pdftk A=even.pdf B=odd.pdf shuffle A B output collated.pdf

```
### burst - Split into Individual Pages   
Splits a single PDF into one file per page. Output files are named using `printf`-style formatting (default: `pg\_%04d.pdf`).   
```
pdftk input.pdf burst output page_%02d.pdf

```
### rotate - Rotate Pages   
Rotates specified pages while maintaining document order. Uses the same page range syntax as `cat`.   
```
pdftk in.pdf cat 1-endeast output rotated.pdf

```
### generate\_fdf - Extract Form Data   
Creates an FDF file from a PDF form, capturing current field values.   
```
pdftk form.pdf generate_fdf output form_data.fdf

```
### fill\_form - Populate Form Fields   
Fills PDF form fields from an FDF or XFDF data file.   
```
pdftk form.pdf fill_form data.fdf output filled.pdf flatten

```
### background - Apply Watermark Behind Content   
Applies a single-page PDF as a background (watermark) behind every page of the input. The input PDF should have a transparent background for best results.   
```
pdftk input.pdf background watermark.pdf output watermarked.pdf

```
### multibackground - Apply Multi-Page Watermark   
Like `background`, but applies corresponding pages from the background PDF to matching pages in the input.   
```
pdftk input.pdf multibackground watermarks.pdf output watermarked.pdf

```
### stamp - Overlay on Top of Content   
Stamps a single-page PDF on top of every page of the input. Use this instead of `background` when the overlay PDF is opaque or has no transparency.   
```
pdftk input.pdf stamp overlay.pdf output stamped.pdf

```
### multistamp - Multi-Page Overlay   
Like `stamp`, but applies corresponding pages from the stamp PDF to matching pages in the input.   
```
pdftk input.pdf multistamp overlays.pdf output stamped.pdf

```
### dump\_data - Export Metadata   
Outputs PDF metadata, bookmarks, and page metrics to a text file.   
```
pdftk input.pdf dump_data output metadata.txt

```
### dump\_data\_utf8 - Export Metadata (UTF-8)   
Same as `dump\_data`, but outputs UTF-8 encoded text.   
```
pdftk input.pdf dump_data_utf8 output metadata_utf8.txt

```
### dump\_data\_fields - Extract Form Field Info   
Reports form field information including type, name, and values.   
```
pdftk form.pdf dump_data_fields output fields.txt

```
### dump\_data\_fields\_utf8 - Extract Form Field Info (UTF-8)   
Same as `dump\_data\_fields`, but outputs UTF-8 encoded text.   
### dump\_data\_annots - Extract Annotations   
Reports PDF annotation information.   
```
pdftk input.pdf dump_data_annots output annots.txt

```
### update\_info - Modify Metadata   
Updates PDF metadata and bookmarks from a text file (same format as `dump\_data` output).   
```
pdftk input.pdf update_info metadata.txt output updated.pdf

```
### update\_info\_utf8 - Modify Metadata (UTF-8)   
Same as `update\_info`, but expects UTF-8 encoded input.   
### attach\_files - Embed Files   
Attaches files to a PDF, optionally at a specific page.   
```
pdftk input.pdf attach_files table.html graph.png to_page 6 output output.pdf

```
### unpack\_files - Extract Attachments   
Extracts file attachments from a PDF.   
```
pdftk input.pdf unpack_files output /path/to/output/

```
## Output Options   
|                 Option   <br> |                                                          Description   <br> |
|:------------------------------|:----------------------------------------------------------------------------|
|    `output <filename>`   <br> | Specify output file. Use `-` for stdout or `PROMPT` for interactive.   <br> |
|       `encrypt\_40bit`   <br> |                                          Apply 40-bit RC4 encryption   <br> |
|      `encrypt\_128bit`   <br> |             Apply 128-bit RC4 encryption (default when password set)   <br> |
| `owner\_pw <password>`   <br> |                                               Set the owner password   <br> |
|  `user\_pw <password>`   <br> |                                                Set the user password   <br> |
|  `allow <permissions>`   <br> |                               Grant specific permissions (see below)   <br> |
|             `compress`   <br> |                                                Compress page streams   <br> |
|           `uncompress`   <br> |                       Decompress page streams (useful for debugging)   <br> |
|              `flatten`   <br> |                                Flatten form fields into page content   <br> |
|    `need\_appearances`   <br> |                        Signal viewer to regenerate field appearances   <br> |
|      `keep\_first\_id`   <br> |                                Preserve document ID from first input   <br> |
|      `keep\_final\_id`   <br> |                                 Preserve document ID from last input   <br> |
|            `drop\_xfa`   <br> |                                                 Remove XFA form data   <br> |
|              `verbose`   <br> |                                     Enable detailed operation output   <br> |
|            `dont\_ask`   <br> |                                         Suppress interactive prompts   <br> |
|              `do\_ask`   <br> |                                           Enable interactive prompts   <br> |

## Permissions   
Use with the `allow` keyword when encrypting. Available permissions:   
|          Permission   <br> |                   Description   <br> |
|:---------------------------|:-------------------------------------|
|          `Printing`   <br> |   Allow high-quality printing   <br> |
|  `DegradedPrinting`   <br> |    Allow low-quality printing   <br> |
|    `ModifyContents`   <br> |    Allow content modification   <br> |
|          `Assembly`   <br> |       Allow document assembly   <br> |
|      `CopyContents`   <br> |         Allow content copying   <br> |
|     `ScreenReaders`   <br> |    Allow screen reader access   <br> |
| `ModifyAnnotations`   <br> | Allow annotation modification   <br> |
|            `FillIn`   <br> |            Allow form fill-in   <br> |
|       `AllFeatures`   <br> |         Grant all permissions   <br> |

## Key Notes   
- Page numbers are one-based; use the `end` keyword for the final page   
- Handles are optional when working with a single PDF   
- Filter mode (no operation specified) applies output options without restructuring   
- Reverse page references use the `r` prefix (e.g., `r1` = last page, `r2` = second-to-last)   
- The `background` operation requires a transparent input; use `stamp` for opaque overlay PDFs   
- Output filename cannot match any input filename   
[PDFtk Server Manual Reference](pdftk-server-manual-reference.md)    
