---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2025-07-08T14:55:28Z"
Created by:
    - mammhoud
id: bafyreiewymzeyoazrsr4kb4ewsma7e4xn2ial5vefcnn2x4acdsi7hzdhm
---
# Mail   
[Mail](mail.md)    
