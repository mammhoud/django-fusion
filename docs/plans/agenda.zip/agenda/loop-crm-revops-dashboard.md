# Loop-CRM RevOps Dashboard   
> Description: The dashboard KPIs served by GET /apis/core/dashboard/ — revenue trend, deal pipeline totals, and the POS vs deal revenue split.   

## KPIs   
|                              KPI   <br> |                              Source   <br> |
|:----------------------------------------|:-------------------------------------------|
| Revenue trend (POS + deal split)   <br> |          `RevenueEvent` + `PosSale`   <br> |
|    Deal pipeline totals by stage   <br> |        `crm.Deal` + `PipelineStage`   <br> |
|               Attributed revenue   <br> | `attribution.AttributionTouchpoint`   <br> |

## Refresh   
- On-request (dashboard API); data recomputed server-side per tenant   
   
## Related   
- → `../apis/loop-crm-core-api.md` — Dashboard endpoint   
- → `../../diagrams/api-request-flows.md` § 2 — Request sequence   
- → `../objects/dashboard.md` — Dashboard object type   
[Loop-CRM RevOps Dashboard](loop-crm-revops-dashboard.md)    
[Task](task.md)    
