---
# yaml-language-server: $schema=schemas/plan.schema.json
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreigr7ddq7xbabczoktaerrjc3aeth7o7bxvboitu7qcja3s3dghtym
---
# Marketing and Sales Strategy — Expanded (Legacy)   
> Historical file. This is the legacy expanded variant exported from an older Anytype workspace. The canonical version is ../marketing-strategy.md.   

## Related Docs   
- → `[../marketing-strategy.md](marketing-and-sales-strategy.md)` — Canonical marketing strategy   
- → `../../README.md` — Anytype hub   
[Marketing and Sales Strategy — Expanded (Legacy)](marketing-and-sales-strategy-expanded-legacy.md)    
