---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-08-05T20:07:44Z"
Created by:
    - mammhoud
id: bafyreievkcfpk3k73hmwbk6w75hwfvdhpmyur4zzu66tspwq6exlg3pwfq
---
# lib-urlpattern   
[lib-urlpattern](lib-urlpattern.md)    
