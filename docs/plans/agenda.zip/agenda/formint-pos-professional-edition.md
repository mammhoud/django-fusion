---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Active
Edition: Formint Professional
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreidkzbnpfrgtknipltj3ogthwlc4ketpqeacn7aqfetap32a4y4tqa
---
# Formint POS — Professional Edition   
> Description: Canonical Anytype summary of the Professional restaurant POS. The repository plan remains the detailed engineering source; this object records product boundaries, methods, use cases, and release gates.   

## Product intent   
Formint is the commercial successor to POS Full and the destination for POS Solo and Forge parity. It serves restaurants, cafés, cloud kitchens, chains, and franchises with Arabic-first, RTL, offline-capable operations.   
## Edition contract   
|                                     Area   <br> | Community   <br> | Formint Professional   <br> | POS Cloud   <br> |
|:------------------------------------------------|:-----------------|:----------------------------|:-----------------|
|    Core POS, catalog, inventory, reports   <br> |  Included   <br> |             Included   <br> |  Included   <br> |
|               Multi-branch, KDS, QR Menu   <br> |         —   <br> |             Included   <br> |  Included   <br> |
|       Loyalty, API access, mobile waiter   <br> |         —   <br> |             Included   <br> |  Included   <br> |
| Hosted billing, backups, tenant controls   <br> |         —   <br> |             Optional   <br> |  Included   <br> |

## Methods and use cases   
|              Method   <br> |                                                                 Responsibility   <br> |                                                                        Use case   <br> |
|:---------------------------|:--------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------|
|   Branch management   <br> |                    Publish catalogs, permissions, stock, and reports by branch   <br> |    A chain manager compares branches while each branch can keep selling offline   <br> |
|        KDS workflow   <br> | Route tickets to stations; track queued, preparing, ready, and recalled states   <br> |                    Kitchen staff finish orders without returning to the cashier   <br> |
|     Menu publishing   <br> |                       Version localized menus and expose branch/table QR links   <br> |                                    Guests scan a current Arabic or English menu   <br> |
|      Loyalty ledger   <br> |             Record earn, redeem, expiry, refund, and reversal events immutably   <br> |            A customer receives correct rewards after an offline retry or refund   <br> |
|          API access   <br> |                                Expose versioned, scoped resources and webhooks   <br> | A delivery, accounting, or analytics partner integrates without database access   <br> |
|       Mobile waiter   <br> |                   Manage tables, drafts, modifiers, notes, and kitchen handoff   <br> |                       Waiters take orders from a phone or tablet during service   <br> |
|  Restaurant catalog   <br> |     Preserve combos, required choices, modifiers, extras, taxes, and snapshots   <br> |    A meal deal remains correct on the receipt and KDS after its catalog changes   <br> |
| Notes and templates   <br> |     Separate line, kitchen, customer, internal, receipt, and preparation notes   <br> |                        Kitchen instructions do not leak onto a customer receipt   <br> |
|        Offline sync   <br> |                                  Queue idempotent events and surface conflicts   <br> |                     A branch reconnects after an outage without duplicate sales   <br> |

## Rendering and asset boundary   
- Astro owns page shells, section structure, preloaders, skeletons, empty/error/offline states, transitions, and responsive layout.   
- Alpine.js owns local interaction state such as carts, dialogs, table selection, and filters.   
- HTMX requests narrowly scoped Django data fragments; Django does not return full layouts or loading components.   
- Django and django-fusion own domain rules, permissions, forms, tables, routing, and lean data responses. Formint does not depend on Wagtail.   
- A shared `assets/` directory sits beside `frontend/` and `backend/`; it contains canonical images, icons, fonts, styles, scripts, manifests, and visual fixtures.   
   
## Design contract   
Semantic color tokens, light/dark/system modes, high-contrast statuses, Arabic RTL, reduced motion, keyboard focus, touch targets, responsive tables, KDS second-screen layouts, and print/receipt styling are release requirements. Use Astro-owned skeletons and stable HTMX targets for loading behavior.   
## Migration and removal gate   
Forge and legacy Solo code remain available until each Formint contract has an implementation, migration fixture, acceptance test, visual evidence, rollback release, and dead-code report. Required parity includes KDS, loyalty, combos, modifiers, extras, notes, receipts, responsive design, semantic colors, and selected Tauri desktop capabilities.   
## Related   
- → `../../../plans/editions/03-pro.md` — Detailed repository plan   
- → `forge-migration.md` — Forge transfer and retirement gates   
- → `tauri-desktop.md` — Native desktop tools and use cases   
- → `cloud.md` — Cloud-only transport boundary   
- → `pos-market-research.md` — Edition market research   
- → `../architecture/editions.md` — Edition architecture   
- → `../objects/edition.md` — Edition object type   
[Formint POS — Professional Edition](formint-pos-professional-edition.md)    
