---
# yaml-language-server: $schema=schemas/release.schema.json
Object type:
    - Release
Created by:
    - mammhoud
Creation date: "2026-09-09T21:41:38Z"
id: bafyreid6vonjzyqzzrrkgcc367ynalpr63zh4afixsxb45dlvotzswp3oa
---
# Formint Editions 2026-10 — Editions   
> Description: Community, Standard, and Pro editions completed with the canonical per-edition plans; Cloud on staging.   

## What shipped   
- Community ✅ done — refunds & returns, offline-first (Rust/Diesel/SQLite)   
- Standard ✅ done — multi-currency, tax profiles, custom roles, export, sync queue   
- Pro 🟡 staging — merged p`os-full `+ p`os-solo,` required Django backend   
- Cloud 🟡 staging — schema-per-tenant master, backups, monitoring   
- Umbrella plan `finish-community-standard` archived (superseded by the per-edition chain — see the ✅ Shipped milestone in `../../feature-tracking.md` § Formint POS)   
   
## Evidence   
- Per-edition `make check`/`make test` green   
- Chain status recorded in `../../../plans/editions/README.md`   
   
## Related   
- → `../editions/\_index.md` — Edition objects   
- → `../../feature-tracking.md` § Formint POS — ✅ Shipped milestone   
- → `../objects/release.md` — Release object type   
[Formint Editions 2026-10 — Editions](formint-editions-2026-10-editions.md)    
[Task](task.md)    
