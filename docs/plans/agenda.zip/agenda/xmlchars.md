---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-07-22T11:28:11Z"
Created by:
    - mammhoud
id: bafyreiejrnkyoquemhuhjfcx52uetakd7pzo2r4hi2dgnndikvcanz3vte
---
# xmlchars   
[xmlchars](xmlchars.md)    
