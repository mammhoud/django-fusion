---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-08-29T20:39:16Z"
Created by:
    - mammhoud
id: bafyreihxyry7sl6bw34hz6mpgcgh3cutzjf5rry2czmlgjvk3nhgjseka4
---
# copywriting   
[copywriting](copywriting.md)    
