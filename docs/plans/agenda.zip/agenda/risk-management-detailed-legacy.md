---
# yaml-language-server: $schema=schemas/plan.schema.json
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreiemtye3kak236yejiwp54wl3qebupsbz6qwv77dn2u5lqlcwcakzi
---
# Risk Management — Detailed (Legacy)   
> Historical file. This is the legacy detailed variant exported from an older Anytype workspace. The canonical version is ../risk-management.md.   

## Related Docs   
- → `[../risk-management.md](risk-management-assessment-and-mitigation.md)` — Canonical risk management plan   
- → `../../README.md` — Anytype hub   
[Risk Management — Detailed (Legacy)](risk-management-detailed-legacy.md)    
