---
# yaml-language-server: $schema=schemas/workspace.schema.json
Status: Active
Object type:
    - Workspace
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreichjgwvem4phihr276ifv5ezfn2oixu4kppgg6ns3lfbbfrjbwpjq
---
# Project Workspace — Portfolio & Planning Hub   
> Description: Central navigation object connecting products, projects, teams, plans, campaigns, sales work, social channels, and delivery evidence.   

## Operating map   
- **Projects** → Products → Editions → Features   
- **Plans** → Goals → Milestones → Tasks   
- **Campaigns** → Channels → Leads → Sales   
- **Online commerce** → Offers → Checkout → Orders   
- **Teams** → Owners → Reviews → Releases   
   
## Workspace methods   
|             Method   <br> |                                     Responsibility   <br> |                                       Use case   <br> |
|:--------------------------|:----------------------------------------------------------|:------------------------------------------------------|
|   Portfolio review   <br> |       Compare product, project, and edition status   <br> |         Leadership chooses the next investment   <br> |
| Quarterly planning   <br> |   Convert goals into plans, milestones, and owners   <br> |                Teams commit to measurable work   <br> |
|  Campaign planning   <br> | Connect audience, message, channel, offer, and KPI   <br> |        Marketing launches a traceable campaign   <br> |
|     Sales planning   <br> |  Connect leads, demos, trials, proposals, and wins   <br> |   Sales sees the path from interest to revenue   <br> |
|     Product review   <br> |     Connect customer evidence to roadmap decisions   <br> |    Product development follows validated needs   <br> |
|        Team review   <br> |         Show ownership, capacity, and dependencies   <br> | Work is assigned without hidden responsibility   <br> |

## Governance rules   
- Every active plan has an owner, status, target outcome, and related product or project.   
- Every campaign has a target audience, channel, message, offer, KPI, and evidence source.   
- Every sales plan identifies the buyer, qualification method, funnel stage, and handoff owner.   
- Every product claim links to research, a release, or an approved claims-register entry.   
   
## Related   
- → `../README.md` — Anytype hub   
- → `projects.md` — Project directory and repository map   
- → `../products/\_index.md` — Product portfolio   
- → `marketing-campaigns.md` — Campaign planning   
- → `sales.md` — Sales planning   
- → `online-commerce.md` — Online selling   
- → `product-development.md` — Product delivery   
- → `social-networks.md` — Social channel plan   
- → `team.md` — Team operating plan   
[Project Workspace — Portfolio &amp; Planning Hub](project-workspace-portfolio-and-planning-hub.md)    
