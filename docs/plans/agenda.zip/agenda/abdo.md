---
# yaml-language-server: $schema=schemas/person.schema.json
Status: Active
Role: Contributor
Object type:
    - Person
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreifdfhvkcmhtiws5yx2sjzeadz5dk2o5ey6w7u7bmu3detu7zcqjjy
---
# Abdo   
> Sales and Marketing Contributor.   

## Responsibilities   
- Content and Videos contributions   
- Project support and collaboration   
   
## Periodic Tasks   
|           Task   <br> |   Cadence   <br> |      Team   <br> |
|:----------------------|:-----------------|:-----------------|
| Content review   <br> | Bi-weekly   <br> | Marketing   <br> |

## Related   
- → `../people.md` — Person object type   
- → `../../decisions/\_index.md` — Architecture decisions   
- → `../../blog/\_index.md` — Blog posts   
[Abdo](abdo.md)    
