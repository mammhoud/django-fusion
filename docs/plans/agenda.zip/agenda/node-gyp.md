---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-07-22T11:28:12Z"
Created by:
    - mammhoud
id: bafyreiaovujlzgj64fqbdxhfadfounqhvhbzo4sbctvgu7rggzj2seco5q
---
# node-gyp   
[node-gyp](node-gyp.md)    
