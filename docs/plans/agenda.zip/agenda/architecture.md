---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Backlinks:
    - 165c9f11.md
Creation date: "2026-05-07T05:09:39Z"
Created by:
    - mammhoud
id: bafyreiazwbdw37uxc3qr7fr5gcl5crbf2b2wtqhwei2r7nuya3klzty3ki
---
# Architecture   
VResume uses a modern, scalable architecture built on proven technologies. This section covers the technical architecture and design decisions.   
## System Architecture   
```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend Layer                        │
│  Tailwind v4 + Preline + HTMX + Alpine.js + Bootstrap 5    │
└────────────────────────┬────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────────┐
│                      API Layer                              │
│  Django REST Framework + Wagtail API                        │
└────────────────────────┬────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────────┐
│                    Application Layer                        │
│  Django 5 + Wagtail 6 + Celery                             │
│  ┌──────────────┬──────────────┬──────────────┐            │
│  │ Blog App     │ Newsletter   │ Pages App    │            │
│  │              │ App          │              │            │
│  └──────────────┴──────────────┴──────────────┘            │
│  ┌──────────────────────────────────────────┐              │
│  │ Handlers App (Shared Models & Services)  │              │
│  └──────────────────────────────────────────┘              │
└────────────────────────┬────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────────┐
│                    Data Layer                               │
│  PostgreSQL + Redis + Celery                               │
└─────────────────────────────────────────────────────────────┘

```
## Technology Stack   
### Frontend   
- **Tailwind CSS v4** - Utility-first CSS with `tw:` prefix   
- **Preline UI** - Component library   
- **HTMX** - Modern interactions   
- **Alpine.js** - Lightweight JavaScript   
- **Bootstrap 5** - Admin interface   
- **Webpack 5** - Module bundler   
   
### Backend   
- **Django 5** - Web framework   
- **Wagtail 6** - CMS platform   
- **Django REST Framework** - API   
- **Celery** - Task queue   
- **django-unfold** - Admin interface   
- **django-bird** - Component system   
   
### Database   
- **PostgreSQL** - Primary database   
- **Redis** - Cache & message broker   
- **SQLite** - Development database   
   
### DevOps   
- **Docker** - Containerization   
- **Docker Compose** - Local development   
- **GitHub Actions** - CI/CD   
- **AWS** - Cloud hosting (optional)   
   
## Application Structure   
### Django Apps   
### Blog App (apps/blog/)   
**Purpose:** Manage blog posts and track article reads   
**Models:**   
- `BlogIndexPage` - Blog index page   
- `BlogPage` - Individual blog post   
- `BlogCategory` - Post categories   
- `BlogTag` - Post tags   
- `ArticleRead` - Read tracking   
   
**Features:**   
- Rich text editor   
- Category and tag management   
- Article read tracking   
- Per-session deduplication   
   
### Newsletter App (apps/newsletter/)   
**Purpose:** Manage subscribers and send campaigns   
**Models:**   
- `Subscriber` - Newsletter subscribers   
- `Campaign` - Email campaigns   
- `EmailDelivery` - Delivery tracking   
   
**Features:**   
- Subscriber management   
- Campaign creation   
- Open tracking (pixel)   
- Click tracking (redirect)   
- Delivery analytics   
   
### Pages App (apps/pages/)   
**Purpose:** Manage portfolio pages   
**Models:**   
- `HomePage` - Main portfolio page   
- `ContactPage` - Contact page   
- `AboutPage` - About page   
   
**Features:**   
- vCard sections   
- HTMX tab navigation   
- Modal components   
- Contact form   
   
### Handlers App (apps/handlers/)   
**Purpose:** Shared models and services   
**Models:**   
- `Organization` - Company information   
- `Service` - Service offerings   
- `FormSubmission` - Contact form submissions   
- `VCardSettings` - Site-wide settings   
   
**Features:**   
- Wagtail snippets   
- Admin interface   
- Email services   
- File processing   
   
## Data Models   
### Blog Models   
```
BlogPage
├── title: CharField
├── slug: SlugField
├── featured_image: ImageField
├── body: StreamField
├── category: ForeignKey(BlogCategory)
├── tags: ManyToManyField(BlogTag)
├── page_views: IntegerField
└── published_at: DateTimeField

ArticleRead
├── post: ForeignKey(BlogPage)
├── user: ForeignKey(User, nullable)
├── session_key: CharField
├── ip_address: GenericIPAddressField
├── read_at: DateTimeField
└── read_duration_seconds: PositiveIntegerField

```
### Newsletter Models   
```
Subscriber
├── email: EmailField
├── name: CharField
├── status: CharField (confirmed/unconfirmed)
├── confirmed_at: DateTimeField
├── ip_address: GenericIPAddressField
├── referrer_url: URLField
└── tags: ManyToManyField(SubscriberTag)

Campaign
├── name: CharField
├── subject: CharField
├── content: TextField
├── status: CharField (draft/sending/sent)
├── blog_post: ForeignKey(BlogPage, nullable)
├── sent_at: DateTimeField
├── total_sent: IntegerField
├── total_opened: IntegerField
└── total_clicked: IntegerField

EmailDelivery
├── campaign: ForeignKey(Campaign)
├── subscriber: ForeignKey(Subscriber)
├── tracking_token: CharField
├── sent_at: DateTimeField
├── opened_at: DateTimeField
├── open_count: PositiveIntegerField
├── clicked_at: DateTimeField
├── click_count: PositiveIntegerField
├── bounced: BooleanField
└── unsubscribed_via_email: BooleanField

```
## API Endpoints   
### Blog API   
- `GET /api/blog/posts/` - List blog posts   
- `GET /api/blog/posts/{id}/` - Get blog post   
- `POST /api/blog/posts/{id}/track-read/` - Track article read   
- `GET /api/blog/categories/` - List categories   
- `GET /api/blog/tags/` - List tags   
   
### Newsletter API   
- `GET /api/newsletter/subscribers/` - List subscribers   
- `POST /api/newsletter/subscribers/` - Create subscriber   
- `GET /api/newsletter/campaigns/` - List campaigns   
- `POST /api/newsletter/campaigns/` - Create campaign   
- `POST /api/newsletter/campaigns/{id}/send/` - Send campaign   
   
### Pages API   
- `GET /api/pages/home/` - Get home page   
- `GET /api/pages/projects/` - List projects   
- `GET /api/pages/projects/{id}/` - Get project   
- `POST /api/pages/contact/` - Submit contact form   
   
## Tracking System   
### Article Read Tracking   
**Flow:**   
1. User visits article page   
2. JavaScript sends read event after 30 seconds   
3. Backend creates `ArticleRead` record   
4. Deduplication by session\_key prevents duplicates   
5. `BlogPage.page\_views` incremented   
   
**Deduplication:**   
- Per session\_key (browser session)   
- Per post   
- One record per session   
   
### Email Tracking   
**Open Tracking:**   
1. Campaign sent with tracking pixel   
2. Pixel URL: `/newsletter/track/open/{token}/`   
3. Backend increments `open\_count`   
4. Sets `opened\_at` timestamp   
5. Updates campaign `total\_opened`   
   
**Click Tracking:**   
1. Links wrapped with tracking redirect   
2. Redirect URL: `/newsletter/track/click/{token}/{url\_hash}/`   
3. Backend increments `click\_count`   
4. Sets `clicked\_at` timestamp   
5. Redirects to actual URL   
   
## Caching Strategy   
### Cache Layers   
1. **Browser Cache** - Static assets (1 year)   
2. **CDN Cache** - Images and media (1 month)   
3. **Redis Cache** - Database queries (1 hour)   
4. **Database Cache** - Computed values (real-time)   
   
### Cache Keys   
- `blog:posts:{id}` - Blog post   
- `blog:categories` - All categories   
- `newsletter:subscribers:{id}` - Subscriber   
- `pages:home` - Home page   
   
## Task Queue (Celery)   
### Tasks   
**Email Tasks:**   
- `send\_campaign\_email` - Send email to subscriber   
- `send\_campaign\_to\_all` - Send campaign to all subscribers   
- `send\_confirmation\_email` - Send confirmation email   
   
**Maintenance Tasks:**   
- `cleanup\_old\_reads` - Remove old read records   
- `generate\_analytics` - Generate analytics reports   
- `sync\_external\_data` - Sync with external services   
   
### Task Configuration   
```
CELERY_BROKER_URL = 'redis://localhost:6379/0'
CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = 'UTC'

```
## Security Architecture   
### Authentication   
- Django session-based authentication   
- CSRF protection   
- Secure password hashing (PBKDF2)   
   
### Authorization   
- Django permission system   
- Role-based access control   
- Object-level permissions   
   
### Data Protection   
- HTTPS enforced   
- SQL injection prevention   
- XSS protection   
- CORS configured   
   
### Privacy   
- GDPR compliant   
- Cookie consent   
- Data retention policies   
- User data export   
   
## Performance Optimization   
### Frontend   
- Code splitting   
- Lazy loading   
- Image optimization   
- CSS/JS minification   
- Gzip compression   
   
### Backend   
- Database indexing   
- Query optimization   
- Caching strategy   
- Async tasks   
- Connection pooling   
   
### Infrastructure   
- CDN for static assets   
- Load balancing   
- Auto-scaling   
- Database replication   
- Backup strategy   
   
## Deployment Architecture   
### Development   
- Local Docker Compose   
- SQLite database   
- Redis in-memory   
- Celery eager mode   
   
### Staging   
- AWS EC2 instances   
- RDS PostgreSQL   
- ElastiCache Redis   
- S3 for media   
- CloudFront CDN   
   
### Production   
- AWS ECS (Fargate)   
- RDS PostgreSQL (Multi-AZ)   
- ElastiCache Redis (Cluster)   
- S3 for media   
- CloudFront CDN   
- Route 53 DNS   
- CloudWatch monitoring   
   
## Monitoring & Logging   
### Monitoring   
- Application Performance Monitoring (APM)   
- Error tracking (Sentry)   
- Uptime monitoring   
- Performance metrics   
   
### Logging   
- Centralized logging (ELK)   
- Application logs   
- Access logs   
- Error logs   
- Audit logs   
   
## Scalability   
### Horizontal Scaling   
- Stateless application servers   
- Load balancing   
- Database replication   
- Cache clustering   
   
### Vertical Scaling   
- Increased server resources   
- Database optimization   
- Cache optimization   
- Query optimization   
   
## Design Decisions   
### Why Django + Wagtail?   
- Mature, battle-tested framework   
- Excellent documentation   
- Large community   
- Built-in admin interface   
- Security best practices   
   
### Why Tailwind + Preline?   
- Utility-first approach   
- Highly customizable   
- Small bundle size   
- Great component library   
- Active community   
   
### Why HTMX?   
- Minimal JavaScript   
- Server-side rendering   
- Progressive enhancement   
- Great performance   
- Easy to learn   
   
### Why Celery?   
- Distributed task queue   
- Reliable job processing   
- Scheduled tasks   
- Retry logic   
- Monitoring   
   
## JavaScript Architecture   
- [JS Architecture Overview](/Users/mammhoud/Library/Application Support/Kiro/User/History/-165c9f11/js-architecture.md) — Bundle structure, initialization flow, core managers   
- [JS Codebase Analysis](/Users/mammhoud/Library/Application Support/Kiro/User/History/-165c9f11/js-codebase-analysis.md) — File-by-file reference for all JS modules   
- [vCard Components](/Users/mammhoud/Library/Application Support/Kiro/User/History/-165c9f11/vcard-components.md) — Sidebar, portfolio filter, contact form, testimonials   
- [Pages Layout System](/Users/mammhoud/Library/Application Support/Kiro/User/History/-165c9f11/pages-layout-system.md) — PagesManager, BaseLayout, LayoutManager   
- [Preloader Component](/Users/mammhoud/Library/Application Support/Kiro/User/History/-165c9f11/preloader.md) — Page loading screen component   
   
## Next Steps   
- [Deployment Guide](/Users/mammhoud/Library/Application Support/Kiro/User/History/deployment.md)   
- [Development Guide](/Users/mammhoud/Library/Application Support/Kiro/User/History/development.md)   
- [API Reference](/Users/mammhoud/Library/Application Support/Kiro/User/History/api/index.md)   
 --- 
   
**Questions?** [Join our Community](https://github.com/yourusername/vresume/discussions)   
