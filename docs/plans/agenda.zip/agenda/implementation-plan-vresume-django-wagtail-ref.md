---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Backlinks:
    - vresume-refactor.md
Creation date: "2026-05-07T12:20:41Z"
Created by:
    - mammhoud
id: bafyreierga6oiltw7ntlxyh7m4sqwlfv43zdvco2ezvijkp7zhu63yfwoi
---
# Implementation Plan: VResume Django/Wagtail Refactor   
## Overview   
This implementation plan breaks down the VResume refactor into discrete, actionable coding tasks organized across seven phases. Each task builds incrementally on previous work, establishing a solid foundation with templates and structure before advancing to complex features like Wagtail integration and HTMX interactions. The plan prioritizes design and template structure first, ensuring maintainability and designer collaboration throughout the refactor.   
 --- 
## Phase 1: Design & Templates (Foundation)   
- [ ] 0. Analyze and integrate existing templates   
- Analyze `VResume/v1/assets/templates/layout/` directory structure   
- Analyze `VResume/v1/assets/templates/email/` directory structure   
- Analyze `VResume/v1/assets/templates/newsletters/` directory structure   
- Analyze `VResume/v1/assets/templates/partials/` directory structure   
- Document existing template inheritance and usage patterns   
- Identify templates to preserve, refactor, or consolidate   
- *Requirements: 10.1, 10.2*   
   
- [ ] 0.1 Consolidate error pages into errors/ directory   
- Create `VResume/v1/assets/templates/errors/` directory   
- Move `400.html`, `401.html`, `403.html`, `404.html`, `429.html` to `errors/`   
- Move `500.html`, `502.html`, `503.html`, `504.html` to `errors/`   
- Update Django settings to reference new error page paths   
- *Requirements: 10.3*   
   
- [ ] 0.2 Reorganize page templates to <page\_name>/{sections/\*.html, main.html} structure   
- Create `VResume/v1/assets/templates/pages/` directory   
- Create subdirectories: `home/`, `about/`, `resume/`, `portfolio/`, `skills/`, `contact/`   
- Create `main.html` in each page directory   
- Create `sections/` subdirectory in each page directory   
- Move existing page-specific templates to appropriate sections/ directories   
- *Requirements: 10.2*   
   
- [ ] 0.3 Update all template includes and extends statements   
- Search for all template includes referencing old paths   
- Update includes to reference new template paths   
- Update extends statements to reference new base templates   
- Verify all template references are correct   
- *Requirements: 10.5*   
   
- [ ] 1. Establish template hierarchy and directory structure   
- Review existing `base.html`, `base\_page.html`, `base\_email.html` templates   
- Document existing template blocks and inheritance chain   
- Create `TEMPLATE\_STRUCTURE.md` documenting the complete template hierarchy   
- Verify all existing templates follow naming conventions   
- **HINT**: Ensure apps/templates/{layout,pages,components,emails,fragments} directories exist. Each page (home, about, resume, portfolio, skills, contact) should have main.html and sections/ subdirectory.   
- *Requirements: 7.1, 7.2, 7.3, 10.1*   
   
- [ ] 2. Create reusable component templates   
- [ ] 2.1 Review and enhance navigation components   
- Review existing `layout/partials/navigations.html`   
- Review existing `partials/header/` components   
- Enhance with responsive design and HTMX attributes   
- **HINT**: Add Preline navbar styling. Use Bootstrap responsive classes. Add Tailwind classes (tw: prefix). Add {% trans %} tags for translations. Add hx-get, hx-target, hx-push-url attributes for HTMX. Ensure navbar stays visible during HTMX section updates. Reference VResume/\_backup/index.html for navbar design.   
- *Requirements: 7.3*   
   
- [ ] 2.2 Create card and list components   
- Create `apps/templates/components/card.html` with Preline card styling   
- Create `apps/templates/components/list.html` with Bootstrap list styling   
- **HINT**: Use Preline card components. Apply Bootstrap grid. Add Tailwind classes (tw: prefix). Include {% trans %} tags for labels. Support both static and dynamic (Wagtail) content. Add hover effects and animations (AOS data attributes). Reference VResume/\_backup/index.html for design patterns.   
- *Requirements: 7.3*   
   
- [ ] 2.3 Review and enhance form components   
- Review existing form templates in `partials/`   
- Enhance with Preline components and Bootstrap styling   
- *Requirements: 7.3*   
   
- [ ] 2.4 Create modal components   
- Create `assets/templates/pages/portfolio/sections/modal.html`   
- Create `assets/templates/pages/contact/sections/confirmation\_modal.html`   
- *Requirements: 7.3*   
   
- [ ] 3. Create section templates for each page   
- [ ] 3.1 Create home section templates   
- Create `apps/templates/pages/home/sections/hero.html`   
- Create `apps/templates/pages/home/sections/features.html`   
- Create `apps/templates/pages/home/sections/testimonials.html`   
- Create `apps/templates/pages/home/sections/about.html`   
- Create `apps/templates/pages/home/sections/clients.html`   
- Create `apps/templates/pages/home/sections/team.html`   
- Create `apps/templates/pages/home/sections/why\_choose.html`   
- Create `apps/templates/pages/home/sections/listing.html`   
- Create `apps/templates/pages/home/sections/slider.html`   
- **HINT**: Use Preline components (cards, carousels, grids). Apply Bootstrap grid layout. Add Tailwind classes (tw: prefix). Include {% trans %} tags for all static text. Integrate with Wagtail StreamField blocks. Reference VResume/\_backup/index.html for home page design. Add if conditions for Wagtail model data availability.   
- *Requirements: 7.3*   
   
- [ ] 3.2 Create about section templates   
- Create `apps/templates/pages/about/sections/intro.html`   
- Create `apps/templates/pages/about/sections/experience.html`   
- Create `apps/templates/pages/about/sections/team.html`   
- Create `apps/templates/pages/about/sections/testimonials.html`   
- Create `apps/templates/pages/about/sections/clients.html`   
- Create `apps/templates/pages/about/sections/services.html`   
- **HINT**: Use Preline components for layout. Apply Bootstrap grid. Add Tailwind classes (tw: prefix). Include {% trans %} tags for translations. Integrate with Wagtail StreamField blocks. Reference VResume/\_backup/index.html for about page design. Add if conditions for Wagtail model data.   
- *Requirements: 7.3*   
   
- [ ] 3.3 Create resume section templates   
- Create `apps/templates/pages/resume/sections/education.html`   
- Create `apps/templates/pages/resume/sections/experience.html`   
- Create `apps/templates/pages/resume/sections/skills.html`   
- **HINT**: Use Preline timeline components. Apply Bootstrap progress indicators. Add Tailwind classes (tw: prefix). Include {% trans %} tags for translations. Integrate with Wagtail StreamField blocks. Reference VResume/\_backup/index.html for resume design. Add if conditions for Wagtail model data.   
- *Requirements: 7.3*   
   
- [ ] 3.4 Create portfolio section templates   
- Create `apps/templates/pages/portfolio/sections/projects.html`   
- Create `apps/templates/pages/portfolio/sections/project\_detail.html`   
- **HINT**: Use Preline cards with hover effects. Apply Bootstrap grid layout. Add Tailwind classes (tw: prefix). Include {% trans %} tags for translations. Integrate with Wagtail StreamField blocks. Reference VResume/\_backup/index.html for portfolio design. Add if conditions for Wagtail model data.   
- *Requirements: 7.3*   
   
- [ ] 3.5 Create skills section templates   
- Create `apps/templates/pages/skills/sections/skills.html`   
- Create `apps/templates/pages/skills/sections/skills\_grid.html`   
- Create `apps/templates/pages/skills/sections/skills\_by\_category.html`   
- **HINT**: Use Preline progress bars. Apply Bootstrap grid layout. Add Tailwind classes (tw: prefix). Include {% trans %} tags for translations. Integrate with Wagtail StreamField blocks. Reference VResume/\_backup/index.html for skills design. Add if conditions for Wagtail model data.   
- *Requirements: 7.3*   
   
- [ ] 3.6 Create contact section templates   
- Create `apps/templates/pages/contact/sections/form.html`   
- Create `apps/templates/pages/contact/sections/info.html`   
- Create `apps/templates/pages/contact/sections/faq.html`   
- Create `apps/templates/pages/contact/sections/map.html`   
- **HINT**: Use Preline form styling. Apply Bootstrap validation classes. Add Tailwind classes (tw: prefix). Include {% trans %} tags for translations. Integrate with Wagtail StreamField blocks. Reference VResume/\_backup/index.html for contact design. Add if conditions for Wagtail model data.   
- *Requirements: 7.3*   
   
- [ ] 4. Create page main templates   
- Create `apps/templates/pages/home/main.html` extending `layout/skeleton.html`   
- Create `apps/templates/pages/about/main.html` extending `layout/skeleton.html`   
- Create `apps/templates/pages/resume/main.html` extending `layout/skeleton.html`   
- Create `apps/templates/pages/portfolio/main.html` extending `layout/skeleton.html`   
- Create `apps/templates/pages/skills/main.html` extending `layout/skeleton.html`   
- Create `apps/templates/pages/contact/main.html` extending `layout/skeleton.html`   
- **HINT**: Each main.html should include sections with if conditions checking for Wagtail model data. Use same section naming as Wagtail models. Add {% trans %} tags for page titles. Support HTMX partial updates (only render main content when HTMX request). Navigation should remain visible during updates.   
- **REFERENCE**: Use VResume/\_backup/index.html for layout structure and section organization   
- *Requirements: 7.3*   
   
- [ ] 5. Create email templates   
- Review existing `email/` templates   
- Create `assets/templates/email/campaign.html` with email-safe HTML and inline styles   
- Create `assets/templates/email/confirmation.html` for subscription confirmation   
- *Requirements: 8.2, 8.3*   
   
- [ ] 6. Create fragment templates for HTMX responses   
- **CRITICAL**: Move existing fragments from VResume/v1/assets/templates/fragments/ to apps/templates/pages/<page\_name>/fragment.html   
- Move: about.html → apps/templates/pages/about/fragment.html   
- Move: contact.html → apps/templates/pages/contact/fragment.html   
- Move: home.html → apps/templates/pages/home/fragment.html   
- Move: portfolio.html → apps/templates/pages/portfolio/fragment.html   
- Move: resume.html → apps/templates/pages/resume/fragment.html   
- Move: skills.html → apps/templates/pages/skills/fragment.html   
- **HINT**: Each fragment should render ONLY the main content section (no navbar, sidebar, footer). Use Preline + Bootstrap + Tailwind (tw: prefix). Add {% trans %} tags for translations. Support HTMX hx-swap animations.   
- **CLEANUP**: After moving, delete VResume/v1/assets/templates/fragments/ directory   
- *Requirements: 4.5*   
   
- [ ] 7. Set up CSS framework integration   
- Review existing CSS loading via `render\_bundle` in `base.html`   
- Verify Bootstrap and Preline CSS are loaded correctly   
- Document CSS loading order and component mapping in `TEMPLATE\_STRUCTURE.md`   
- Do NOT reorganize static files or assets - keep existing `render\_bundle` approach   
- **HINT**: Ensure CSS loading order is: Tailwind → Bootstrap → Preline. Fix any conflicting Tailwind classes by using tw: prefix. Test responsive design across all breakpoints.   
- **CLEANUP**: After all templates migrated, delete VResume/v1/assets/templates/pages/ directory   
- *Requirements: 5.1, 5.2, 5.3, 10.6*   
   
- [x] 8. Checkpoint - Template structure complete   
- ✅ All template files created and follow naming conventions   
- ✅ Template inheritance chain verified   
- ✅ CSS frameworks (Bootstrap + Preline) configured via render\_bundle   
- ✅ TEMPLATE\_STRUCTURE.md documentation created   
- ✅ Error pages consolidated into errors/ directory   
- ✅ Page templates reorganized into <page\_name>/{sections/\*.html, main.html} structure   
- ✅ Fragment templates created for HTMX responses   
- ✅ 65 total HTML templates created   
 --- 
   
## Phase 2: Admin Migration (Unfold)   
- [ ] 9. Migrate newsletter app admin to Unfold   
- [ ] 9.1 Create `apps/newsletter/admin.py` using Unfold's ModelAdmin   
- Migrate Subscriber admin with list\_display, list\_filter, search\_fields   
- Migrate Campaign admin with analytics display   
- Migrate EmailDelivery admin with tracking display   
- Migrate TrackedURL admin   
- *Requirements: 1.3, 1.4*   
   
- [ ] \* 9.2 Write unit tests for newsletter admin   
- Test admin list display and filtering   
- Test custom admin actions   
- *Requirements: 1.4*   
   
- [ ] 10. Migrate handlers app admin to Unfold   
- Create `apps/handlers/admin.py` using Unfold's ModelAdmin   
- Migrate all handler models to Unfold   
- Port custom admin actions to Unfold implementation   
- *Requirements: 1.3, 1.4*   
   
- [ ] 11. Migrate pages app admin to Unfold   
- Create `apps/pages/admin.py` using Unfold's ModelAdmin   
- Migrate all page models to Unfold   
- Ensure Wagtail page admin still works alongside Unfold   
- *Requirements: 1.3, 1.4*   
   
- [ ] 12. Migrate blog app admin to Unfold   
- Create `apps/blog/admin.py` using Unfold's ModelAdmin   
- Migrate all blog models to Unfold   
- *Requirements: 1.3, 1.4*   
   
- [ ] 13. Verify Unfold admin functionality   
- Test admin panel loads with Unfold styling   
- Test all model admins are accessible   
- Test custom actions work in Unfold   
- Test filters and search functionality   
- *Requirements: 1.2, 1.5*   
   
- [ ] 14. Checkpoint - Admin migration complete   
- Verify all admin.py files use Unfold's ModelAdmin   
- Verify admin panel renders correctly   
- Verify all models are accessible in admin   
- Ask the user if questions arise.   
 --- 
   
## Phase 3: App Consolidation (Communications)   
- [ ] 15. Create communications app structure   
- Create `apps/communications/` directory   
- Create `apps/communications/\_\_init\_\_.py`   
- Create `apps/communications/apps.py` with app configuration   
- Create `apps/communications/models/` subdirectory   
- Create `apps/communications/models/\_\_init\_\_.py`   
- Create `apps/communications/forms/` subdirectory   
- Create `apps/communications/views/` subdirectory   
- Create `apps/communications/services/` subdirectory   
- *Requirements: 2.1*   
   
- [ ] 16. Migrate newsletter models to communications app   
- [ ] 16.1 Create Subscriber model in `apps/communications/models/subscriber.py`   
- Copy Subscriber model from newsletter app   
- Ensure all fields, methods, and relationships are preserved   
- *Requirements: 2.2, 2.7*   
   
- [ ] 16.2 Create Campaign model in `apps/communications/models/campaign.py`   
- Copy Campaign model from newsletter app   
- Ensure all fields, methods, and relationships are preserved   
- *Requirements: 2.2, 2.7*   
   
- [ ] 16.3 Create EmailDelivery model in `apps/communications/models/delivery.py`   
- Copy EmailDelivery model from newsletter app   
- Ensure all fields, methods, and relationships are preserved   
- *Requirements: 2.2, 2.7*   
   
- [ ] 16.4 Create TrackedURL model in `apps/communications/models/tracked\_url.py`   
- Copy TrackedURL model from newsletter app   
- Ensure all fields, methods, and relationships are preserved   
- *Requirements: 2.2, 2.7*   
   
- [ ] 17. Create Skill model in communications app   
- Create `apps/communications/models/skill.py`   
- Implement Skill model with name, category, description, icon, order, is\_visible fields   
- Add Meta class with ordering and verbose names   
- *Requirements: 6.1*   
   
- [ ] 18. Update communications app models **init**.py   
- Import all models (Subscriber, Campaign, EmailDelivery, TrackedURL, Skill)   
- Export models for easy importing   
- *Requirements: 2.2*   
   
- [ ] 19. Migrate handlers models to communications app   
- Identify all models in handlers app   
- Copy models to `apps/communications/models/`   
- Update model imports and relationships   
- *Requirements: 2.3*   
   
- [ ] 20. Create data migrations for model consolidation   
- [ ] 20.1 Create migration to move Subscriber data from newsletter to communications   
- Create data migration file   
- Write migration logic to copy data   
- *Requirements: 2.4*   
   
- [ ] 20.2 Create migration to move Campaign data from newsletter to communications   
- Create data migration file   
- Write migration logic to copy data   
- *Requirements: 2.4*   
   
- [ ] 20.3 Create migration to move EmailDelivery data from newsletter to communications   
- Create data migration file   
- Write migration logic to copy data   
- *Requirements: 2.4*   
   
- [ ] 20.4 Create migration to move TrackedURL data from newsletter to communications   
- Create data migration file   
- Write migration logic to copy data   
- *Requirements: 2.4*   
   
- [ ] 20.5 Create migration to move handlers data to communications   
- Create data migration file   
- Write migration logic to copy data   
- *Requirements: 2.4*   
   
- [ ] 21. Update INSTALLED\_APPS configuration   
- Update `v1/configs/base/apps.py`   
- Add `apps.communications` to LOCAL\_APPS   
- Remove `apps.newsletter` from LOCAL\_APPS   
- Remove `apps.handlers` from LOCAL\_APPS   
- *Requirements: 2.5*   
   
- [ ] 22. Update all imports across codebase   
- Search for imports from `apps.newsletter` and update to `apps.communications`   
- Search for imports from `apps.handlers` and update to `apps.communications`   
- Update views, forms, services, and other modules   
- *Requirements: 2.6*   
   
- [ ] 23. Create communications app admin   
- Create `apps/communications/admin.py` using Unfold's ModelAdmin   
- Register Subscriber, Campaign, EmailDelivery, TrackedURL, Skill models   
- Implement admin actions (send campaign, mark confirmed, etc.)   
- *Requirements: 2.1, 1.3*   
   
- [ ] 24. Verify app consolidation   
- Run migrations to move data   
- Verify all data moved correctly   
- Test admin functionality for communications app   
- Test all imports work correctly   
- *Requirements: 2.7*   
   
- [ ] 25. Checkpoint - App consolidation complete   
- Verify communications app is in INSTALLED\_APPS   
- Verify all models are accessible in admin   
- Verify all data migrated successfully   
- Verify all imports updated across codebase   
- Ask the user if questions arise.   
 --- 
   
## Phase 4: Wagtail Hybrid Integration   
- [ ] 26. Create base Wagtail page model   
- Create `apps/pages/models/base.py`   
- Implement BasePage model extending wagtail.models.Page   
- Add hybrid rendering support with fragment\_template attribute   
- Implement serve() method to handle HTMX requests   
- Implement get\_context() method to extend context with Wagtail data   
- *Requirements: 3.1, 3.4*   
   
- [ ] 27. Create specialized Wagtail page models   
- [ ] 27.1 Create ResumePage model in `apps/pages/models/pages/resume.py`   
- Extend BasePage   
- Add StreamField for resume sections   
- Add template and fragment\_template attributes   
- *Requirements: 3.1, 3.2*   
   
- [ ] 27.2 Create PortfolioPage model in `apps/pages/models/pages/portfolio.py`   
- Extend BasePage   
- Add StreamField for portfolio sections   
- Add template and fragment\_template attributes   
- *Requirements: 3.1, 3.2*   
   
- [ ] 27.3 Create SkillsPage model in `apps/pages/models/pages/skills.py`   
- Extend BasePage   
- Add StreamField for skills sections   
- Add template and fragment\_template attributes   
- Add get\_context() to include Skill objects   
- *Requirements: 3.1, 3.2, 6.3*   
   
- [ ] 27.4 Create AboutPage model in `apps/pages/models/pages/about.py`   
- Extend BasePage   
- Add StreamField for about sections   
- Add template and fragment\_template attributes   
- *Requirements: 3.1, 3.2*   
   
- [ ] 28. Create Wagtail StreamField blocks   
- [ ] 28.1 Create `apps/communications/blocks.py`   
- Create SkillsBlock for displaying skills in StreamField   
- Create CampaignBlock for embedding campaigns   
- *Requirements: 3.2, 6.3*   
   
- [ ] 28.2 Create `apps/pages/blocks.py`   
- Create TextBlock for rich text content   
- Create ImageBlock for images   
- Create VideoBlock for embedded videos   
- *Requirements: 3.2*   
   
- [ ] 29. Implement hybrid rendering with fallback   
- [ ] 29.1 Create rendering utility in `apps/core/rendering.py`   
- Implement function to check for Wagtail page data   
- Implement fallback to traditional template rendering   
- *Requirements: 3.4, 3.7*   
   
- [ ] 29.2 Update page templates to support hybrid rendering   
- Update `apps/templates/pages/resume.html` with fallback logic   
- Update `apps/templates/pages/portfolio.html` with fallback logic   
- Update `apps/templates/pages/skills.html` with fallback logic   
- Update `apps/templates/pages/about.html` with fallback logic   
- *Requirements: 3.4, 3.7*   
   
- [ ] 30. Create Wagtail admin configuration   
- Create `apps/pages/admin.py` for Wagtail page admin   
- Register page models with Wagtail admin   
- Configure content panels for each page type   
- *Requirements: 3.6*   
   
- [ ] 31. Test Wagtail page creation and publishing   
- Create test Wagtail pages for each page type   
- Verify pages render correctly in Wagtail admin   
- Verify published pages display on website   
- *Requirements: 3.1, 3.6*   
   
- [ ] 32. Checkpoint - Wagtail hybrid integration complete   
- Verify Wagtail page models are created   
- Verify hybrid rendering works (Wagtail data used when available)   
- Verify fallback rendering works (traditional templates used when no Wagtail data)   
- Verify Wagtail admin is accessible   
- Ask the user if questions arise.   
 --- 
   
## Phase 5: HTMX & URL Structure   
- [ ] 33. Set up HTMX integration   
- Add HTMX JavaScript library to `apps/static/js/htmx.min.js`   
- Create `apps/static/js/app.js` with HTMX configuration   
- Update `apps/templates/base.html` to include HTMX script   
- *Requirements: 4.1*   
   
- [ ] 34. Create HTMX middleware for request detection   
- Create `apps/core/middleware.py`   
- Implement middleware to detect HTMX requests (HX-Request header)   
- Add htmx flag to request object   
- *Requirements: 4.1*   
   
- [ ] 35. Implement partial page update views   
- [ ] 35.1 Create view for home section   
- Implement view that returns full page for direct navigation   
- Implement view that returns fragment for HTMX requests   
- *Requirements: 4.1, 4.5, 4.7*   
   
- [ ] 35.2 Create view for about section   
- Implement view that returns full page for direct navigation   
- Implement view that returns fragment for HTMX requests   
- *Requirements: 4.1, 4.5, 4.7*   
   
- [ ] 35.3 Create view for resume section   
- Implement view that returns full page for direct navigation   
- Implement view that returns fragment for HTMX requests   
- *Requirements: 4.1, 4.5, 4.7*   
   
- [ ] 35.4 Create view for portfolio section   
- Implement view that returns full page for direct navigation   
- Implement view that returns fragment for HTMX requests   
- *Requirements: 4.1, 4.5, 4.7*   
   
- [ ] 35.5 Create view for skills section   
- Implement view that returns full page for direct navigation   
- Implement view that returns fragment for HTMX requests   
- *Requirements: 4.1, 4.5, 4.7*   
   
- [ ] 35.6 Create view for contact section   
- Implement view that returns full page for direct navigation   
- Implement view that returns fragment for HTMX requests   
- *Requirements: 4.1, 4.5, 4.7*   
   
- [ ] 36. Update URL routing for clean URLs   
- Update `v1/apps/urls.py`   
- Add routes for each section: `/`, `/about/`, `/resume/`, `/portfolio/`, `/skills/`, `/contact/`   
- Ensure URLs follow pattern without query parameters or `/tab/` segments   
- *Requirements: 4.3, 4.4*   
   
- [ ] 37. Update navigation templates with HTMX attributes   
- [ ] 37.1 Update navbar with HTMX links   
- Add `hx-get`, `hx-target`, `hx-push-url` attributes to navigation links   
- *Requirements: 4.1, 4.2*   
   
- [ ] 37.2 Update sidebar with HTMX links   
- Add `hx-get`, `hx-target`, `hx-push-url` attributes to section links   
- *Requirements: 4.1, 4.2*   
   
- [ ] 38. Implement URL push state handling   
- Update `apps/static/js/app.js` to handle URL updates   
- Ensure browser history works correctly with HTMX   
- Ensure page title updates when section changes   
- *Requirements: 4.3, 4.4*   
   
- [ ] 39. Test HTMX partial updates   
- Test clicking navigation links triggers HTMX requests   
- Test content area updates without full page reload   
- Test URL updates correctly   
- Test direct navigation to section URLs works   
- *Requirements: 4.1, 4.2, 4.5, 4.7*   
   
- [ ] 40. Checkpoint - HTMX and URL structure complete   
- Verify HTMX requests return only content section   
- Verify full page requests return complete page   
- Verify URLs follow clean pattern without query parameters   
- Verify navigation state preserved across updates   
- Ask the user if questions arise.   
 --- 
   
## Phase 6: Skills & Content Management   
- [ ] 41. Create Skill model admin in Unfold   
- Update `apps/communications/admin.py`   
- Register Skill model with Unfold's ModelAdmin   
- Add list\_display, list\_filter, search\_fields   
- Add ordering and visibility toggle   
- *Requirements: 6.2*   
   
- [ ] 42. Create SkillsBlock for Wagtail StreamField   
- Update `apps/communications/blocks.py`   
- Implement SkillsBlock that displays skills grouped by category   
- Add block configuration for display options   
- *Requirements: 6.3*   
   
- [ ] 43. Implement skills section rendering   
- [ ] 43.1 Create skills view   
- Implement view to fetch and display skills   
- Support both Wagtail and traditional rendering   
- *Requirements: 6.4, 3.4*   
   
- [ ] 43.2 Update skills template   
- Update `apps/templates/pages/skills.html`   
- Implement skills grouping by category   
- *Requirements: 6.4*   
   
- [ ] 43.3 Update skills fragment template   
- Update `apps/templates/fragments/skills.html`   
- Implement skills grouping by category for HTMX responses   
- *Requirements: 6.4*   
   
- [ ] 44. Test skills management   
- Create test skills via admin   
- Verify skills display correctly grouped by category   
- Verify skills can be reordered via admin   
- Verify skills visibility toggle works   
- *Requirements: 6.2, 6.4, 6.5*   
   
- [ ] 45. Checkpoint - Skills and content management complete   
- Verify Skill model is accessible in admin   
- Verify skills display correctly on website   
- Verify skills can be managed without code changes   
- Ask the user if questions arise.   
 --- 
   
## Phase 7: Newsletter-Blog Integration   
- [ ] 46. Create email template rendering service   
- Create `apps/communications/services/email\_renderer.py`   
- Implement function to render campaign HTML email   
- Implement function to generate plain text fallback   
- *Requirements: 8.2, 8.3*   
   
- [ ] 47. Implement blog-to-campaign integration   
- [ ] 47.1 Update Campaign model   
- Add blog\_post ForeignKey to Wagtail Page   
- Add method to extract blog content for email   
- *Requirements: 8.1*   
   
- [ ] 47.2 Create campaign creation view   
- Implement view to create campaign from blog post   
- Implement view to preview campaign email   
- *Requirements: 8.1, 8.4*   
   
- [ ] 48. Create email styling system   
- [ ] 48.1 Create email CSS inliner   
- Create `apps/communications/services/email\_styler.py`   
- Implement function to inline CSS for email compatibility   
- *Requirements: 8.4*   
   
- [ ] 48.2 Update email templates with styling   
- Update `apps/templates/email/campaign.html` with email-safe styles   
- Update `apps/templates/email/confirmation.html` with email-safe styles   
- *Requirements: 8.2, 8.4*   
   
- [ ] 49. Implement email tracking integration   
- [ ] 49.1 Create tracking pixel endpoint   
- Create view to handle tracking pixel requests   
- Update EmailDelivery model to record opens   
- *Requirements: 8.5*   
   
- [ ] 49.2 Create click tracking endpoint   
- Create view to handle click tracking requests   
- Update EmailDelivery and TrackedURL models to record clicks   
- *Requirements: 8.5*   
   
- [ ] 50. Test newsletter-blog integration   
- Create test blog post   
- Create campaign from blog post   
- Verify campaign email renders correctly   
- Verify tracking pixels work   
- Verify click tracking works   
- *Requirements: 8.1, 8.2, 8.3, 8.4, 8.5*   
   
- [ ] 51. Checkpoint - Newsletter-blog integration complete   
- Verify campaigns can be created from blog posts   
- Verify email templates render correctly   
- Verify tracking works correctly   
- Ask the user if questions arise.   
 --- 
   
## Property-Based Tests   
- [ ] \* 52. Write property test for model functionality preservation   
- **Property 1: Model Functionality Preservation After Migration**   
- **Validates: Requirements 2.7**   
- Test that all migrated models maintain their methods and relationships   
- Test that model queries return same results before and after migration   
   
- [ ] \* 53. Write property test for hybrid rendering fallback   
- **Property 2: Hybrid Rendering Fallback**   
- **Validates: Requirements 3.4, 3.7**   
- Test that Wagtail data is used when available   
- Test that fallback rendering works when Wagtail data unavailable   
- Test that both rendering paths produce valid HTML   
   
- [ ] \* 54. Write property test for HTMX partial responses   
- **Property 3: HTMX Partial Response Content**   
- **Validates: Requirements 4.2, 4.5**   
- Test that HTMX responses contain only content section   
- Test that HTMX responses do not contain navbar, sidebar, or footer   
- Test that full page requests contain complete layout   
   
- [ ] \* 55. Write property test for clean URL structure   
- **Property 4: Clean URL Structure**   
- **Validates: Requirements 4.3, 4.4**   
- Test that all section URLs follow `/section-name/` pattern   
- Test that no query parameters appear in URLs   
- Test that no `/tab/` segments appear in URLs   
   
- [ ] \* 56. Write property test for skills grouping   
- **Property 5: Skills Grouping by Category**   
- **Validates: Requirements 6.4**   
- Test that all skills are grouped by category   
- Test that skills within each category are ordered correctly   
- Test that hidden skills do not appear in rendered output   
   
- [ ] \* 57. Write property test for email round-trip rendering   
- **Property 6: Email Round-Trip Rendering**   
- **Validates: Requirements 8.3**   
- Test that HTML email renders correctly   
- Test that plain text conversion preserves core message   
- Test that email styling does not break content   
   
- [ ] \* 58. Write property test for email tracking data integrity   
- **Property 7: Email Tracking Data Integrity**   
- **Validates: Requirements 8.5**   
- Test that open tracking increments open\_count correctly   
- Test that click tracking increments click\_count correctly   
- Test that no duplicate tracking records are created   
   
- [ ] \* 59. Write property test for content change reflection   
- **Property 8: Content Change Reflection**   
- **Validates: Requirements 9.2**   
- Test that Wagtail content changes appear immediately on website   
- Test that no cache invalidation required   
- Test that changes persist across page reloads   
   
- [ ] \* 60. Write property test for version history maintenance   
- **Property 9: Version History Maintenance**   
- **Validates: Requirements 9.6**   
- Test that version history is created for content changes   
- Test that previous versions are retrievable   
- Test that rollback to previous version works   
   
- [ ] \* 61. Write property test for direct section navigation   
- **Property 10: Direct Section Navigation**   
- **Validates: Requirements 4.7**   
- Test that direct navigation to section URL returns full page   
- Test that correct section is displayed   
- Test that navigation state is correct   
 --- 
   
## Final Checkpoint   
- [ ] 62. Final verification and testing   
  - Run full test suite   
  - Verify all migrations run successfully   
  - Verify admin interface works correctly   
  - Verify website renders correctly   
  - Verify HTMX interactions work correctly   
  - Verify email templates render correctly   
  - Ask the user if questions arise.   
 --- 
## Notes   
- Tasks marked with `\*` are optional property-based tests and can be skipped for faster MVP   
- Each task references specific requirements for traceability   
- Checkpoints ensure incremental validation and allow user feedback   
- Property tests validate universal correctness properties defined in the design   
- Unit tests validate specific examples and edge cases   
- All tasks assume the design and requirements documents are available during implementation   
- The implementation follows a strict phase order to ensure dependencies are met   
- Template structure is prioritized before advanced features to ensure maintainability   
 --- 
   
## Task Dependency Graph   
```
{
  "waves": [
    { "id": 0, "tasks": ["1", "2.1", "2.2", "2.3", "2.4", "3.1", "3.2", "3.3", "3.4", "3.5", "3.6", "4", "5", "6", "7"] },
    { "id": 1, "tasks": ["9.1", "10", "11", "12", "13"] },
    { "id": 2, "tasks": ["15", "16.1", "16.2", "16.3", "16.4", "17", "18", "19"] },
    { "id": 3, "tasks": ["20.1", "20.2", "20.3", "20.4", "20.5", "21", "22", "23", "24"] },
    { "id": 4, "tasks": ["26", "27.1", "27.2", "27.3", "27.4", "28.1", "28.2"] },
    { "id": 5, "tasks": ["29.1", "29.2", "30", "31"] },
    { "id": 6, "tasks": ["33", "34", "35.1", "35.2", "35.3", "35.4", "35.5", "35.6", "36", "37.1", "37.2", "38", "39"] },
    { "id": 7, "tasks": ["41", "42", "43.1", "43.2", "43.3", "44"] },
    { "id": 8, "tasks": ["46", "47.1", "47.2", "48.1", "48.2", "49.1", "49.2", "50"] },
    { "id": 9, "tasks": ["52", "53", "54", "55", "56", "57", "58", "59", "60", "61"] }
  ]
}

```
