---
# yaml-language-server: $schema=schemas/workspace.schema.json
Status: Published
Object type:
    - Workspace
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreieybywfx27qq3exzc73ubxqgro45iweq7edkbqjpzvez3a2tp4ci4
---
# Auth — Authentication & Authorization System   
> Type: Workspace 🏢   
> Description: Cross-site authentication powered by django-allauth with django-fusion auth mixins. Supports email/password, social login, MFA (TOTP), and HTMX-based flows.   

 --- 
## Overview   
Auth is implemented uniformly across all sites using django-allauth:   
|                  Auth Feature   <br> |       Status   <br> |               Implementation   <br> |
|:-------------------------------------|:--------------------|:------------------------------------|
|          Email/Password Login   <br> |   ✅ Complete   <br> |      allauth account adapter   <br> |
| Social Login (Google, GitHub)   <br> |   ✅ Complete   <br> |      Social account adapters   <br> |
|                  Registration   <br> |   ✅ Complete   <br> |             HTMX modal flows   <br> |
|                Password Reset   <br> |   ✅ Complete   <br> |            Email-based reset   <br> |
|                MFA (TOTP 2FA)   <br> |   ✅ Complete   <br> |   Two-factor auth in profile   <br> |
|           WebAuthn / Passkeys   <br> |    📋 Planned   <br> |         allauth.mfa WebAuthn   <br> |
|            Session Management   <br> |   ✅ Complete   <br> | django-fusion session mixins   <br> |

 --- 
## Auth Flow Summary   
|               Flow   <br> |                     URL Pattern   <br> | HTMX   <br> | Modal   <br> |
|:--------------------------|:---------------------------------------|:------------|:-------------|
|              Login   <br> |              `/accounts/login/`   <br> |    ✅   <br> |     ✅   <br> |
|             Signup   <br> |             `/accounts/signup/`   <br> |    ✅   <br> |     ✅   <br> |
|     Password Reset   <br> |     `/accounts/password/reset/`   <br> |    ✅   <br> |     ✅   <br> |
|    Password Change   <br> |    `/accounts/password/change/`   <br> |    ✅   <br> |     ✅   <br> |
|   Email Management   <br> |              `/accounts/email/`   <br> |    ✅   <br> |     ✅   <br> |
|       Social Login   <br> |       `/accounts/social/login/`   <br> |    ✅   <br> |     ✅   <br> |
| Social Connections   <br> | `/accounts/social/connections/`   <br> |    ✅   <br> |     ✅   <br> |
|          MFA Setup   <br> |          `/accounts/2fa/setup/`   <br> |    ✅   <br> |     ✅   <br> |

## Supporting Libraries   
|             Library   <br> |                                                      Role   <br> |
|:---------------------------|:-----------------------------------------------------------------|
|    `django-allauth`   <br> |                                            Auth framework   <br> |
|     `django-fusion`   <br> | Auth mixins (LoginRequiredMixin, PermissionRequiredMixin)   <br> |
| `hijack` (dev only)   <br> |                               Impersonation for debugging   <br> |

 --- 
## Project Context   
|              Aspect   <br> |                                                                      Description   <br> |
|:---------------------------|:----------------------------------------------------------------------------------------|
|         **Library**   <br> |                                       django-allauth + django-fusion auth mixins   <br> |
|           **Color**   <br> |   Blue (#3b82f6) / Indigo (#6366f1) — representing trust, security, and identity   <br> |
| **Account Adapter**   <br> |                     `plugins.accounts.adapters.RegistrationAdapter` (HTMX-aware)   <br> |
|       **MFA Model**   <br> |                  `two\_factor\_enabled` / `two\_factor\_secret` on profile model   <br> |

 --- 
## Color Palette: Auth Blue   
|   Token   <br> |                    Hex   <br> |                            Usage   <br> |
|:---------------|:------------------------------|:----------------------------------------|
| Primary   <br> |   `#3b82f6` (Blue-500)   <br> | Login buttons, auth form accents   <br> |
| Surface   <br> |  `#eff6ff` / `#172554`   <br> |          Auth pages (light/dark)   <br> |
|  Accent   <br> | `#6366f1` (Indigo-500)   <br> |       MFA indicators, 2FA badges   <br> |
| Success   <br> |  `#22c55e` (Green-500)   <br> |          Verified, authenticated   <br> |
|  Danger   <br> |    `#ef4444` (Red-500)   <br> |            Auth errors, lockouts   <br> |

 --- 
## Related Docs   
- → `../../../../AGENTS.md` — Auth adapter details   
- → `../../../../projects/precis/precis-main/backend/apps/auth/adapters.py` — Auth implementation   
- → `../README.md` — Master index   
