---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Published
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreifyg2nl3rokgfjtbvdfo6reqyfbw4nfmmk43j6lyhaw2ofvv5gxku
---
# Pricing Plans   
> Scope: Pricing strategy, revenue targets, token cost modeling, and feature-based pricing for Structa Cloud products   
> Updated: 2026-08-28   

 --- 
## Revenue targets   
### Formint POS — 12-month client targets   
|      Edition   <br> | Target Clients   <br> |                               Target Segment   <br> |                           Strategy   <br> |
|:--------------------|:----------------------|:----------------------------------------------------|:------------------------------------------|
|     Standard   <br> |     60 clients   <br> |              Growing independent restaurants   <br> | ThemeForest listing + direct sales   <br> |
| Professional   <br> |     30 clients   <br> |       Restaurants needing cloud sync + admin   <br> |         Contact/consultative sales   <br> |
|        Cloud   <br> |      5 clients   <br> | Chains, franchises, multi-location operators   <br> | Contact/register + payment gateway   <br> |

 --- 
## Precis LMS — workspace model   
|            Plan   <br> |                   Audience   <br> |                       Workspace Model   <br> |  Price Point   <br> |
|:-----------------------|:----------------------------------|:---------------------------------------------|:--------------------|
| Instructor Free   <br> |     Individual instructors   <br> |           1 workspace, basic features   <br> |         Free   <br> |
|  Instructor Pro   <br> |         Active instructors   <br> |        1 workspace, advanced features   <br> |  $9.99/month   <br> |
|    Center Basic   <br> |       Small course centers   <br> |          3 workspaces, basic features   <br> | $29.99/month   <br> |
|      Center Pro   <br> |      Medium course centers   <br> |      10 workspaces, advanced features   <br> | $99.99/month   <br> |
|      Enterprise   <br> | Large centers/institutions   <br> | Unlimited workspaces, custom features   <br> |       Custom   <br> |

 --- 
## Precis AI Design Chat — token-based pricing   
### Model cost structure   
| Model Tier   <br> |              Provider   <br> | Cost per 1k messages   <br> |                   Use Case   <br> |
|:------------------|:-----------------------------|:----------------------------|:----------------------------------|
|     Budget   <br> | Gemini 2.0 Flash-Lite   <br> |             ~$0.0006   <br> | Light chat, simple prompts   <br> |
|   Standard   <br> |      Gemini 2.5 Flash   <br> |             ~$0.0019   <br> |        General design chat   <br> |
|    Premium   <br> |     Claude Sonnet 4.6   <br> |             ~$0.0173   <br> |   Complex design reasoning   <br> |
|   Flagship   <br> |           GPT-5.6 Sol   <br> |             ~$0.0231   <br> |    Advanced creative tasks   <br> |

### Recommended pricing   
|       Plan   <br> | Monthly Price   <br> | Included Tokens   <br> |                                Features   <br> |
|:------------------|:---------------------|:-----------------------|:-----------------------------------------------|
|       Free   <br> |            $0   <br> |      10k tokens   <br> |           10 messages/day, basic models   <br> |
|    Starter   <br> |         $9.99   <br> |     100k tokens   <br> |            All standard models, history   <br> |
|        Pro   <br> |        $29.99   <br> |     500k tokens   <br> |    Premium models, priority, API access   <br> |
| Enterprise   <br> |        Custom   <br> |       Unlimited   <br> | Flagship models, dedicated support, SLA   <br> |

 --- 
## Pricing recommendations by product   
### Formint POS   
|      Edition   <br> |               Pricing Model   <br> |                    Recommended Price   <br> |                                 Notes   <br> |
|:--------------------|:-----------------------------------|:--------------------------------------------|:---------------------------------------------|
|    Community   <br> |          Free / Open source   <br> |                                   $0   <br> |              GitHub, community-driven   <br> |
|     Standard   <br> | One-time + optional support   <br> |                     $49–$99 one-time   <br> | ThemeForest listing; lifetime updates   <br> |
| Professional   <br> |                Subscription   <br> |   $19.99–$29.99/month per restaurant   <br> | Includes cloud sync, admin, invoicing   <br> |
|        Cloud   <br> |                Subscription   <br> |       $49.99–$99.99/month per tenant   <br> |     Multi-terminal, multi-branch, KDS   <br> |
|       Client   <br> |      Free (Cloud-dependent)   <br> |                                   $0   <br> |                    Bundled with Cloud   <br> |

### Precis LMS   
|            Plan   <br> | Monthly Price   <br> | Annual Price   <br> | Workspaces   <br> |              Target   <br> |
|:-----------------------|:---------------------|:--------------------|:------------------|:---------------------------|
| Instructor Free   <br> |            $0   <br> |           $0   <br> |          1   <br> | Student acquisition   <br> |
|  Instructor Pro   <br> |         $9.99   <br> |     $99/year   <br> |          1   <br> |        Monetization   <br> |
|    Center Basic   <br> |        $29.99   <br> |    $299/year   <br> |          3   <br> |       Small centers   <br> |
|      Center Pro   <br> |        $99.99   <br> |    $999/year   <br> |         10   <br> |      Medium centers   <br> |
|      Enterprise   <br> |        Custom   <br> |       Custom   <br> |  Unlimited   <br> |  Large institutions   <br> |

### Loop-CRM   
|       Plan   <br> | Monthly Price   <br> |  Contacts   <br> |                               Features   <br> |               Target   <br> |
|:------------------|:---------------------|:-----------------|:----------------------------------------------|:----------------------------|
|    Starter   <br> |            $0   <br> |       100   <br> |                       Basic CRM, forms   <br> | Trial/small business   <br> |
|     Growth   <br> |        $29.99   <br> |     1,000   <br> |         Pipelines, automation, reports   <br> |          Small teams   <br> |
|        Pro   <br> |        $99.99   <br> |    10,000   <br> | Advanced automation, API, integrations   <br> |      Medium business   <br> |
| Enterprise   <br> |        Custom   <br> | Unlimited   <br> |          Custom features, SLA, support   <br> |           Enterprise   <br> |

 --- 
## Pricing levers   
1. **Token-based** — Precis AI Chat; aligns cost with usage   
2. **Workspace-based** — Precis LMS; scales with team size   
3. **Contact-based** — Loop-CRM; scales with customer base   
4. **Terminal/tenant-based** — Formint Cloud; scales with locations   
5. **Feature gates** — All products; free vs paid feature sets   
6. **Support tiers** — Enterprise vs self-serve   
 --- 
   
## 🇸🇦 ملخّص عربي — خطط التسعير   
> النطاق: استراتيجية التسعير، وأهداف الإيرادات، وتكلفة التوكن، والتسعير   
> المبني على الميزات.   

### أهداف الإيرادات (12 شهراً)   
|                 المنتج   <br> |           الهدف   <br> |                                          القطاع   <br> |                                      الاستراتيجية   <br> |
|:------------------------------|:-----------------------|:-------------------------------------------------------|:---------------------------------------------------------|
|          Formint قياسي   <br> |       60 عميلاً   <br> |                              مطاعم مستقلة نامية   <br> |                       قوائم السوق + البيع المباشر   <br> |
|        Formint احترافي   <br> |       30 عميلاً   <br> |                       مطاعم تحتاج مزامنة سحابية   <br> |                                       بيع استشاري   <br> |
|          Formint سحابي   <br> |         5 عملاء   <br> |                             سلاسل ومجموعات فروع   <br> |                             بيع مباشر + بوابة دفع   <br> |

### أسعار المنتجات باختصار   
|                         المنتج   <br> |                            الموديل   <br> |                                   السعر   <br> |
|:--------------------------------------|:------------------------------------------|:-----------------------------------------------|
|                 Formint مجتمعي   <br> |                 مجاني مفتوح المصدر   <br> |                                      $0   <br> |
|                  Formint قياسي   <br> |                         دفعة واحدة   <br> |                                 $49–$99   <br> |
|                Formint احترافي   <br> |                        اشتراك شهري   <br> |                  $19.99–$29.99 لكل مطعم   <br> |
|                  Formint سحابي   <br> |                        اشتراك شهري   <br> |                $49.99–$99.99 لكل مستأجر   <br> |
|            Precis نظام التعلّم   <br> |                   حسب مساحات العمل   <br> |     $0 / $9.99 / $29.99 / $99.99 / مخصص   <br> |
|               Precis محادثة AI   <br> |                         حسب التوكن   <br> |              $0 / $9.99 / $29.99 / مخصص   <br> |
|                       Loop-CRM   <br> |                   حسب جهات الاتصال   <br> |             $0 / $29.99 / $99.99 / مخصص   <br> |

### أدوات التسعير   
التوكن (محادثة AI) · مساحات العمل (نظام التعلّم) · جهات الاتصال (Loop-CRM) ·
الطرفيات والمستأجرون (Formint سحابي) · بوابات الميزات · مستويات الدعم.   
 --- 
## Implementation tasks   
|                                        Task   <br> |           Owner   <br> | Priority   <br> |  Status   <br> |
|:---------------------------------------------------|:-----------------------|:----------------|:---------------|
|        Formint Standard ThemeForest listing   <br> |    Formint team   <br> |       P1   <br> | Planned   <br> |
|      Formint Pro/Cloud sales flow + payment   <br> |    Formint team   <br> |       P1   <br> | Planned   <br> |
| Precis LMS workspace provisioning + billing   <br> |     Precis team   <br> |       P1   <br> | Planned   <br> |
|         Precis AI Chat token billing system   <br> |     Precis team   <br> |       P1   <br> | Planned   <br> |
|                  Loop-CRM feature gap audit   <br> |        CRM team   <br> |       P1   <br> | Planned   <br> |
|          AI model cost monitoring dashboard   <br> | AI/Backend team   <br> |       P2   <br> | Planned   <br> |

 --- 
## Periodic pricing tasks   
|                           Task   <br> |   Cadence   <br> |                Team   <br> |
|:--------------------------------------|:-----------------|:---------------------------|
|     Competitor price benchmark   <br> | Quarterly   <br> |             Product   <br> |
|   Token cost monitoring review   <br> |   Monthly   <br> |             Backend   <br> |
| Revenue target progress review   <br> |   Monthly   <br> |             Product   <br> |
|  Feature-gate audit vs pricing   <br> | Quarterly   <br> | Product + Marketing   <br> |
|   Payment gateway health check   <br> |   Monthly   <br> |             Backend   <br> |

 --- 
## Remarks   
- AI token prices are volatile; build cost monitoring into billing system   
- ThemeForest listing for Standard reduces distribution cost but takes 30–50% commission   
- All prices should be validated against competitor benchmarks before publication   
