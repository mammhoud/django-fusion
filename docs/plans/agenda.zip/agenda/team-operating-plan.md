---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Active
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreic7pusqe253nsgwagr7smkn5esovbusorcd7ydr3msxhpcwumlasm
---
# Team Operating Plan   
> Description: Operating model for product, engineering, marketing, sales, support, and partner teams working on the portfolio.   

## Team map   
|        Team   <br> |                                             Mission   <br> |                                   Owns   <br> |               Members   <br> |
|:-------------------|:-----------------------------------------------------------|:----------------------------------------------|:-----------------------------|
|     Product   <br> |           Validate problems and prioritize outcomes   <br> |     Product objects, research, roadmap   <br> |    Moustafa, Mammhoud   <br> |
| Engineering   <br> |                 Build reliable product capabilities   <br> |       Features, architecture, releases   <br> | Yahia, Asmaa, Mahmoud   <br> |
|   Marketing   <br> |           Explain value and create qualified demand   <br> |    Campaigns, content, social channels   <br> |                     —   <br> |
|       Sales   <br> | Convert qualified demand into sustainable customers   <br> |      Demos, pilots, proposals, revenue   <br> |                     —   <br> |
|     Support   <br> |            Help customers adopt and stay successful   <br> |        Onboarding, incidents, feedback   <br> |                     —   <br> |
|    Partners   <br> |                       Extend reach and integrations   <br> | Channels, referrals, external services   <br> |                     —   <br> |

## Team ownership   
|   Person   <br> |        Role   <br> |        Team   <br> |                                    Primary Focus   <br> |
|:----------------|:-------------------|:-------------------|:--------------------------------------------------------|
| Mammhoud   <br> |     Founder   <br> |  Leadership   <br> |          Architecture, product strategy, roadmap   <br> |
| Moustafa   <br> |     Product   <br> |     Product   <br> | Roadmap, prioritization, cross-team coordination   <br> |
|    Yahia   <br> |   Developer   <br> | Engineering   <br> |                 Feature development, code review   <br> |
|    Asmaa   <br> |   Developer   <br> | Engineering   <br> |                     Feature development, testing   <br> |
|  Mahmoud   <br> |   Developer   <br> | Engineering   <br> |                   Feature development, bug fixes   <br> |
|   Dariia   <br> | Contributor   <br> |     Support   <br> |                        Content and documentation   <br> |

## Operating methods   
- Every active Plan has one accountable owner and one measurable outcome   
- Product, engineering, marketing, and sales review evidence together before major positioning or roadmap changes   
- Campaign and sales feedback returns to Market Research and Product Development   
- Team membership is represented by Person relations; responsibilities are represented by Team and Plan relations   
- Sensitive personal information stays in appropriate private systems; Anytype stores role and work context only   
   
## Periodic team tasks   
### Engineering (Yahia, Asmaa, Mahmoud)   
|                                     Task   <br> |   Cadence   <br> |
|:------------------------------------------------|:-----------------|
| Sprint development work and deliverables   <br> |    Weekly   <br> |
|                Code review participation   <br> |    Weekly   <br> |
|                     Bug triage and fixes   <br> |    Weekly   <br> |
|                 Technical debt reduction   <br> | Bi-weekly   <br> |
|                    Documentation updates   <br> |   Monthly   <br> |

### Product (Moustafa, Mammhoud)   
|                                 Task   <br> |   Cadence   <br> |
|:--------------------------------------------|:-----------------|
| Sprint planning and backlog grooming   <br> |    Weekly   <br> |
|               Product roadmap review   <br> | Bi-weekly   <br> |
|             Customer feedback review   <br> |    Weekly   <br> |
|               Feature prioritization   <br> | Bi-weekly   <br> |
|                      Cross-team sync   <br> |    Weekly   <br> |
|               Product metrics review   <br> |   Monthly   <br> |

### Leadership (Mammhoud)   
|                         Task   <br> |   Cadence   <br> |
|:------------------------------------|:-----------------|
| Architecture decision review   <br> | Bi-weekly   <br> |
|       Product roadmap update   <br> |   Monthly   <br> |
|          Team capacity check   <br> | Bi-weekly   <br> |

## Team cadence   
- **Weekly delivery review** — sprint progress, blockers, evidence   
- **Monthly product/customer review** — roadmap, feedback, metrics   
- **Quarterly portfolio and marketing review** — strategy, claims, pilot decisions   
- **Release retrospective** — learnings, process improvements   
   
## Related   
- → `project-workspace.md` — Workspace hub   
- → `product-development.md` — Development lifecycle   
- → `marketing-campaigns.md` — Campaign ownership   
- → `sales.md` — Sales ownership   
- → `../objects/team.md` — Team object type   
- → `../objects/people.md` — Person object type   
- → `../objects/people/me.md` — Mammhoud   
- → `../objects/people/moustafa.md` — Moustafa   
- → `../objects/people/yahia.md` — Yahia   
- → `../objects/people/asmaa.md` — Asmaa   
- → `../objects/people/mahmoud.md` — Mahmoud   
- → `../objects/people/dariia.md` — Dariia   
[Team Operating Plan](team-operating-plan.md)    
