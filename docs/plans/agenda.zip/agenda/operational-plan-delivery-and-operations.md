---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Published
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreifpohg5kgtkf2ox2pzrmrlns2t2pbzqjul2xghhkv7szkbw5iixy4
---
# Operational Plan — Delivery & Operations   
> Description: Operational processes covering development workflow, production infrastructure, logistics, customer service, and disaster recovery for the Structa Cloud platform.   

## 1. Development Operations   
### 1.1 Development Workflow   
- **Capture** → Anytype workspace captures requirements and links to technical specifications   
- **Create** → Task creation with acceptance criteria and owner assignment   
- **Develop** → Feature branches from main; code with build targets   
- **Test** → pytest, vitest, Django test client validation   
- **Review** → Pull request with CI checks and team review   
- **Deploy** → Merge to main; Docker Compose production deployment   
|   <br>Stage   <br> |                               Tool   <br> |   Responsible   <br> |
|:-------------------|:------------------------------------------|:---------------------|
|    Planning   <br> |                  Anytype workspace   <br> | Product owner   <br> |
| Development   <br> |               VS Code, Build tools   <br> |    Developers   <br> |
|     Testing   <br> | pytest, vitest, Django test client   <br> |    Developers   <br> |
|      Review   <br> |                         GitHub PRs   <br> |          Team   <br> |
|  Deployment   <br> |        Docker Compose, Build tools   <br> |        DevOps   <br> |

### 1.2 Version Control   
- **Repository:** GitHub monorepo with submodules   
- **Branch Strategy:** Feature branches → PR → main   
- **Release Tagging:** Semantic versioning (v1.2.3)   
- **Submodules:** django-fusion, ceptor-ai (pinned versions)   
   
### 1.3 CI/CD Pipelines   
|     Pipeline   <br> |       Provider   <br> |                         Purpose   <br> |
|:--------------------|:----------------------|:---------------------------------------|
|  Pytest Core   <br> | GitHub Actions   <br> |           Run Django test suite   <br> |
|    Deploy CI   <br> | GitHub Actions   <br> |     Build and deploy containers   <br> |
| Check Extras   <br> | GitHub Actions   <br> | Lint, type-check, security scan   <br> |

 --- 
## 2. Production Infrastructure   
### 2.1 Service Architecture   
- **Traefik Proxy** (port 443) — SSL termination and SNI routing   
- **Django App Containers** — Application business logic   
- **Nginx Media Server** — Static files and media serving   
- **PostgreSQL + Redis** — Data persistence and caching   
   
### 2.2 Deployment Order   
| Step   <br> |                Service   <br> |         Dependencies   <br> |
|:------------|:------------------------------|:----------------------------|
|    1   <br> |     PostgreSQL + Redis   <br> |                 None   <br> |
|    2   <br> | Application containers   <br> |       Database ready   <br> |
|    3   <br> |     Nginx media server   <br> |  Application running   <br> |
|    4   <br> |          Traefik proxy   <br> | All services healthy   <br> |

### 2.3 Environment Configuration   
| Environment   <br> |                Purpose   <br> |                   URL   <br> |
|:-------------------|:------------------------------|:-----------------------------|
| Development   <br> |      Local dev servers   <br> |        localhost:50xx   <br> |
|     Staging   <br> | Pre-production testing   <br> | staging.structa.cloud   <br> |
|  Production   <br> |           Live service   <br> |         structa.cloud   <br> |

 --- 
## 3. Customer Service & Support   
|             Tier   <br> | Response Time   <br> |               Channels   <br> |        Included   <br> |
|:------------------------|:---------------------|:------------------------------|:-----------------------|
|    **Community**   <br> |      48 hours   <br> | GitHub Issues, Discord   <br> |       Free tier   <br> |
| **Professional**   <br> |       8 hours   <br> |   Email, ticket system   <br> |    Subscription   <br> |
|   **Enterprise**   <br> |        1 hour   <br> | Phone, dedicated Slack   <br> | Custom contract   <br> |

### Support ticket workflow   
- **Ticket Creation** → Customer submits via GitHub, email, or Discord   
- **Categorisation** → Priority and category assigned   
- **Assignment** → Assigned to appropriate team member   
- **Investigation** → Issue reproduced and root cause identified   
- **Resolution** → Fix applied or workaround provided   
- **Verification** → Customer confirms resolution   
- **Documentation** → Solution documented for future reference   
 --- 
   
## 4. Disaster Recovery   
|             Scenario   <br> |        RTO   <br> |      RPO   <br> |                           Procedure   <br> |
|:----------------------------|:------------------|:----------------|:-------------------------------------------|
|  Database corruption   <br> |    4 hours   <br> |   1 hour   <br> | Restore from latest PostgreSQL dump   <br> |
|    Container failure   <br> | 10 minutes   <br> |        —   <br> |     Auto-restart via Docker Compose   <br> |
| Full service failure   <br> |    2 hours   <br> |   1 hour   <br> |           Redeploy from clean state   <br> |
|   Data center outage   <br> |   24 hours   <br> | 24 hours   <br> |        Failover to secondary region   <br> |

### Backup Strategy   
|            Data   <br> |  Frequency   <br> |   Retention   <br> |        Storage   <br> |
|:-----------------------|:------------------|:-------------------|:----------------------|
| PostgreSQL dump   <br> |      Daily   <br> |     30 days   <br> |  S3-compatible   <br> |
|     Media files   <br> | Continuous   <br> |           —   <br> | Docker volumes   <br> |
|   Configuration   <br> | Per change   <br> | Git history   <br> |         GitHub   <br> |

 --- 
## 5. Security Operations   
|                Area   <br> |                    Measure   <br> |     Frequency   <br> |
|:---------------------------|:----------------------------------|:---------------------|
|    Dependency audit   <br> |       Dependabot, uv audit   <br> |        Weekly   <br> |
|    SSL certificates   <br> | Let's Encrypt auto-renewal   <br> | Every 90 days   <br> |
|       Access review   <br> |    GitHub team permissions   <br> |     Quarterly   <br> |
| Penetration testing   <br> | Third-party security audit   <br> |      Annually   <br> |

 --- 
## Periodic team tasks   
|                       Task   <br> |   Cadence   <br> |        Team   <br> |
|:----------------------------------|:-----------------|:-------------------|
|    Deployment health check   <br> |     Daily   <br> |      DevOps   <br> |
|        Backup verification   <br> |    Weekly   <br> |      DevOps   <br> |
|   Security dependency scan   <br> |    Weekly   <br> | Engineering   <br> |
| Infrastructure cost review   <br> |   Monthly   <br> |     Product   <br> |
|    Disaster recovery drill   <br> | Quarterly   <br> |      DevOps   <br> |
|      SLA compliance review   <br> |   Monthly   <br> |     Support   <br> |

## Related   
- → `product-development.md` — Development lifecycle   
- → `market-research.md` — Market context   
- → `risk-management.md` — Risk assessment   
- → `monitoring.md` — Metrics and monitoring   
- → `../architecture/overview.md` — Architecture reference   
- → `../guides/deployment.md` — Deployment guide   
- → `../README.md` — Master index   
