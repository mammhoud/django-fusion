---
# yaml-language-server: $schema=schemas/workspace.schema.json
Status: Published
Object type:
    - Workspace
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreidldztoyyoeg3h6ls6boh5gcp3xftihu7ebwpjvfx4zx2x44jjxla
---
# Architecture Overview   
> Description: High-level architecture of Structa Cloud — how sites, libraries, and infrastructure fit together.   

## Monorepo layout   
### Projects (core)   
|               Path   <br> |                                 Purpose   <br> |
|:--------------------------|:-----------------------------------------------|
| core/ctc-research/   <br> |                       CTC Research site   <br> |
|     core/lms-demo/   <br> |                           LMS demo site   <br> |
|      core/VResume/   <br> |                            VResume site   <br> |
|       core/tinker/   <br> |                     Template customizer   <br> |
|      core/configs/   <br> |                  Shared Django settings   <br> |
|       core/assets/   <br> | Shared templates, static files, scripts   <br> |
|         core/libs/   <br> |                Local reusable libraries   <br> |
|          core/www/   <br> |                 Shared/core Django code   <br> |
|      core/compose/   <br> |               Dockerfile and entrypoint   <br> |

### Applications and supporting areas   
|                    Path   <br> |                   Purpose   <br> |
|:-------------------------------|:---------------------------------|
|     applications/proxy/   <br> |           Traefik + Nginx   <br> |
| applications/databases/   <br> |        PostgreSQL + Redis   <br> |
|                  tests/   <br> | Shared and per-site tests   <br> |
|                   docs/   <br> |             Documentation   <br> |
|      docker-compose.yml   <br> |        Root orchestration   <br> |

## Technology stack   
|        Layer   <br> |               Technology   <br> |
|:--------------------|:--------------------------------|
|      Backend   <br> |          Django, Wagtail   <br> |
|     Frontend   <br> |      SCSS, Webpack, HTMX   <br> |
|    Libraries   <br> | django-fusion, ceptor-ai   <br> |
|         Auth   <br> |           django-allauth   <br> |
|   Task queue   <br> |           Celery + Redis   <br> |
|     Database   <br> |               PostgreSQL   <br> |
|        Cache   <br> |                    Redis   <br> |
|        Proxy   <br> |                  Traefik   <br> |
| Static/media   <br> |                    Nginx   <br> |
|    Container   <br> |   Docker, Docker Compose   <br> |

## Shared components   
All sites share templates, static files, settings, and libraries. Per-site code lives under its own directory and can override shared templates and styles.   
## Request flow   
- User request hits the proxy   
- Proxy routes to the correct site container based on host   
- The site container runs the Django/Wagtail code for that site   
- Static and media files are served by Nginx   
- Background tasks are processed by background workers   
   
## Data flow   
- PostgreSQL stores application data   
- Redis stores cache and background-task broker state   
- Site media is stored in per-site volumes and served by Nginx   
   
## Scalability   
- New sites can be added under their own directory   
- Shared components reduce duplication   
- Background tasks are centralized in shared workers   
- Multi-domain or single-domain deployment is supported   
   
## Related   
- → `../plans/project-guide.md` — Repository navigation   
- → `../plans/startup-planner.md` — Product and business strategy   
- → `../plans/operational-plan.md` — Deployment and operations   
[Architecture Overview](architecture-overview.md)    
