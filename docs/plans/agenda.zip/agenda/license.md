---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2025-07-06T03:58:42Z"
Created by:
    - mammhoud
id: bafyreiccgwzlbsxarkepdkrar6kky34e2pojpzgdkl56n4qtiejx5g47iy
---
# license   
[license](license.md)    
