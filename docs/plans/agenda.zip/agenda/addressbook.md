---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2025-07-08T14:55:31Z"
Created by:
    - mammhoud
id: bafyreid5fiw5aesodu3mmupc6lnvyg436cgeyjyg2kapvbi2pkziubmsmi
---
# AddressBook   
[AddressBook](addressbook.md)    
