---
# yaml-language-server: $schema=schemas/feature.schema.json
Object type:
    - Feature
Status: Planned
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreifiwhlmk7kiwzkt6qau3c67vsbcd43gspdjaxqarwchyustrhmmmu
---
# Cloud   
> Type: Feature ✨   
> Description: Quiz and assessment engine for the LMS Demo platform — multiple question types, scoring, feedback, and progress tracking.   

 --- 
## Overview   
The Quiz system powers formative and summative assessment across all courses:   
|         Question Type   <br> |                        Description   <br> |           Scoring   <br> |
|:-----------------------------|:------------------------------------------|:-------------------------|
|   **Multiple Choice**   <br> |     Single or multi-select answers   <br> |       Auto-graded   <br> |
|      **True / False**   <br> |                      Binary choice   <br> |       Auto-graded   <br> |
| **Fill in the Blank**   <br> | Text input against expected answer   <br> |       Auto-graded   <br> |
|      **Short Answer**   <br> |                 Free text response   <br> | Instructor-graded   <br> |
|             **Essay**   <br> |                 Long-form response   <br> | Instructor-graded   <br> |
|          **Matching**   <br> |        Pair items from two columns   <br> |       Auto-graded   <br> |
|          **Ordering**   <br> |  Arrange items in correct sequence   <br> |       Auto-graded   <br> |

 --- 
## Project Context   
|              Aspect   <br> |                                                                                Description   <br> |
|:---------------------------|:--------------------------------------------------------------------------------------------------|
|            **Site**   <br> |                                                                    LMS Demo + CTC Research   <br> |
|           **Color**   <br> |   Amber (#f59e0b) / Yellow (#eab308) — representing assessment, challenge, and achievement   <br> |
| **Progress Impact**   <br> |                                     Quiz scores contribute to course completion percentage   <br> |
|            **Tech**   <br> |                                              Wagtail Page models, django-fusion components   <br> |

 --- 
## Color Palette: Quiz Amber   
|     Token   <br> |                    Hex   <br> |                          Usage   <br> |
|:-----------------|:------------------------------|:--------------------------------------|
|   Primary   <br> |  `#f59e0b` (Amber-500)   <br> | Quiz headers, question markers   <br> |
|   Surface   <br> |  `#fffbeb` / `#451a03`   <br> |       Quiz panels (light/dark)   <br> |
|   Correct   <br> |  `#22c55e` (Green-500)   <br> |       Correct answer indicator   <br> |
| Incorrect   <br> |    `#ef4444` (Red-500)   <br> |     Incorrect answer indicator   <br> |
|   Partial   <br> | `#eab308` (Yellow-500)   <br> |       Partial credit indicator   <br> |

 --- 
## Related Docs   
- → `learning-curve.md` — Learning progression   
- → `../guides/development-workflow.md` — Adding quiz components   
- → `../README.md` — Master index   
[Cloud](cloud.md)    
