---
# yaml-language-server: $schema=schemas/person.schema.json
Status: Active
Role: Product
Object type:
    - Person
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreicyzw2b4kq7dfcwf6it2zk46jhpyfksvsbzfbxjnqsj27pksowpsm
---
# Moustafa   
> Product manager responsible for roadmap planning, feature prioritization, and cross-team coordination.   

## Responsibilities   
- Product roadmap planning and prioritization   
- Feature specification and acceptance criteria   
- Cross-team coordination and sprint planning   
- Customer feedback analysis and product iteration   
   
## Owned Products   
- → `../../products/\_index.md` — Product portfolio   
   
## Assigned Teams   
- → `../team.md` — Product team   
   
## Made Decisions   
- → `../decision.md` — Product decisions   
   
## Periodic Tasks   
|                                 Task   <br> |   Cadence   <br> |    Team   <br> |
|:--------------------------------------------|:-----------------|:---------------|
| Sprint planning and backlog grooming   <br> |    Weekly   <br> | Product   <br> |
|               Product roadmap review   <br> | Bi-weekly   <br> | Product   <br> |
|             Customer feedback review   <br> |    Weekly   <br> | Product   <br> |
|               Feature prioritization   <br> | Bi-weekly   <br> | Product   <br> |
|                      Cross-team sync   <br> |    Weekly   <br> | Product   <br> |
|               Product metrics review   <br> |   Monthly   <br> | Product   <br> |
|          Competitive analysis update   <br> | Quarterly   <br> | Product   <br> |

## Related   
- → `../people.md` — Person object type   
- → `../team.md` — Team object   
- → `../product.md` — Product object   
- → `../../plans/team.md` — Team operating plan   
- → `../../plans/product-development.md` — Development lifecycle   
- → `../../plans/project-workspace.md` — Portfolio hub   
[Moustafa](moustafa.md)    
