---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-08-06T14:55:06Z"
Created by:
    - mammhoud
id: bafyreidixgp2wgzeakk5kzwetq2vsarophxbe2th23lfuf66sxrzosllg4
---
# shadcn   
[shadcn](shadcn.md)    
