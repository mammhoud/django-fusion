---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-07-22T11:28:05Z"
Created by:
    - mammhoud
id: bafyreicqrrzuq2vkhth6xotva73ixz2o3emjygbiyf5if3z5xgfnaqxuj4
---
# chownr   
[chownr](chownr.md)    
