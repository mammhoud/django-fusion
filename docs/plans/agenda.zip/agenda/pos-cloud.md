---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Planned
Edition: POS Cloud
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreihhme7mfwukbah2ecgruicmupblo6wkvmknlsym22zx3mzjoe6iwm
---
# POS Cloud   
> Description: SaaS control plane for tenant, branch, sync, analytics, billing, backup, and managed integration services. Local Formint remains useful without this service.   

## Cloud methods and use cases   
|                     Method   <br> |                                                             Responsibility   <br> |                                                     Use case   <br> |
|:----------------------------------|:----------------------------------------------------------------------------------|:--------------------------------------------------------------------|
| Tenant and branch registry   <br> |                  Authenticate organizations, branches, devices, and scopes   <br> |              A franchise owner sees only authorized branches   <br> |
|                Sync broker   <br> | Accept versioned idempotent events, retry, reconcile, and expose conflicts   <br> |          Offline branch sales arrive once after reconnection   <br> |
|           Streaming events   <br> |                          Deliver approved configuration and status changes   <br> |         A menu or approval reaches selected branches quickly   <br> |
|          Central analytics   <br> |                    Aggregate sales, stock, waste, and preparation measures   <br> |                 Managers compare branch performance remotely   <br> |
|         Backup and restore   <br> |                                    Protect tenant data and verify recovery   <br> |       A customer can recover after device or service failure   <br> |
|         Billing and limits   <br> |                       Track subscription, branches, usage, and entitlement   <br> |                    SaaS plans remain commercially measurable   <br> |
|   Webhooks and partner API   <br> |                             Expose scoped cloud events to external systems   <br> | Accounting, delivery, and reporting systems integrate safely   <br> |

## Cloud-only transport boundary   
This is the only POS planning object that may define django-bolt. A cloud-side `BoltAPI` adapter may be evaluated for high-throughput sync, WebSocket streaming, authentication, and cloud OpenAPI exposure. It must not be added to Formint local dependencies, django-fusion, or the local Astro/HTMX path.   
Keep standard Django handlers as the operational fallback for health, administration, migrations, and adapter failure. The portable contract is the versioned event envelope: stable ID, event version, idempotency key, request ID, tenant/branch scope, retry metadata, conflict record, and audit reference.   
## Cloud boundary   
- Local Formint owns checkout, local SQLite, printer state, offline drafts, and branch continuity.   
- Cloud owns tenant identity, cross-branch coordination, hosted PostgreSQL, billing, backups, and central analytics.   
- Cloud does not return local page shells, skeletons, or full UI components.   
- Public cloud endpoints require scoped credentials, rate limits, audit logs, replay protection, and tenant isolation.   
   
## Delivery gates   
1. Define portable sync envelopes and ownership.   
2. Register branches and devices with health/status visibility.   
3. Implement queue, retry, conflict, and batch reconciliation.   
4. Benchmark the cloud transport and complete security/operations review before selecting django-bolt.   
5. Test restore, billing reconciliation, tenant isolation, and local operation when cloud is unavailable.   
   
## Related   
- → `formint-pos-professional-plan.md` — Local product boundary   
- → `pos-market-research.md` — SaaS market research   
- → `../../../plans/editions/04-cloud.md` — Detailed repository cloud plan   
- → `../../../plans/editions/03-pro.md` — Local engineering contract   
- → `../objects/api.md` — API object type   
- → `../objects/integration.md` — Integration object type   
[POS Cloud](pos-cloud.md)    
