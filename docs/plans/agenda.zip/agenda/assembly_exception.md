---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-07-08T03:59:00Z"
Created by:
    - mammhoud
id: bafyreigvt4gn6bbb7x7cryr52nlw743eyqvu67bvmv6c6m2zr76wb3sjyq
---
# ASSEMBLY\_EXCEPTION   
[ASSEMBLY\_EXCEPTION](assembly_exception.md)    
