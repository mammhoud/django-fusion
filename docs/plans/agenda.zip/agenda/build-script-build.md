---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-07-26T11:57:49Z"
Created by:
    - mammhoud
id: bafyreig5puvalutlx6mdfe2ung6zviuodlwzfim3ppkcp73y7bt6vteok4
---
# build-script-build   
[build-script-build](build-script-build.md)    
