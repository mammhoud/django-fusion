---
# yaml-language-server: $schema=schemas/feature.schema.json
Edition: Community, Formint Professional, POS Cloud
Object type:
    - Feature
Status: In Development
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreiauiav22bdp4lwrqvn3yvwpu4de6f6w3lawkznkdvfwfo7um46sse
---
# Integrations — Connectivity & External Systems   
> Type: Feature ✨   
> Description: All integration points for the POS suite — internal system connectivity, cloud/SaaS services, and external business systems (CRM, payments, accounting).   

 --- 
## Overview   
Integrations span three layers:   
|                     Layer   <br> |                                                    Scope   <br> |                        Editions   <br> |
|:---------------------------------|:----------------------------------------------------------------|:---------------------------------------|
| **Internal connectivity**   <br> |               Frontend ↔ sidecar ↔ database, branch sync   <br> |          All editions with sync   <br> |
|        **Cloud services**   <br> | CRM sync, payments, analytics, backups, multi-branch hub   <br> | Formint Professional, POS Cloud   <br> |
|      **External systems**   <br> |            CRM, payment gateways, accounting, email, SMS   <br> | Formint Professional, POS Cloud   <br> |

 --- 
## Internal connectivity   
|          Integration   <br> |         Source   <br> |              Target   <br> |              Protocol   <br> |
|:----------------------------|:----------------------|:---------------------------|:-----------------------------|
|   Frontend ↔ Sidecar   <br> | Tauri React UI   <br> | Python Robyn server   <br> | HTTP REST (port 8766)   <br> |
|   Sidecar ↔ Database   <br> |     Django ORM   <br> | SQLite / PostgreSQL   <br> |         Django models   <br> |
|        Solo ↔ Master   <br> |  Branch device   <br> |       Master server   <br> |             HTTP poll   <br> |
|         Full ↔ Cloud   <br> |  Branch device   <br> |           Cloud API   <br> |     HTTPS + WebSocket   <br> |

 --- 
## Cloud services   
|               Service   <br> |                                          Integration   <br> |                       Benefit   <br> |
|:-----------------------------|:------------------------------------------------------------|:-------------------------------------|
|         **Cloud CRM**   <br> |            Customer profile sync across all branches   <br> |         Unified customer view   <br> |
|   **Payment Gateway**   <br> |             Stripe/Square/PayPal checkout processing   <br> | Online and in-person payments   <br> |
| **Analytics Service**   <br> | Revenue reports, sales trends, inventory forecasting   <br> |         Business intelligence   <br> |
|      **Cloud Backup**   <br> |           Automated database backup to cloud storage   <br> |             Disaster recovery   <br> |
| **Multi-Branch Sync**   <br> |    Centralized data hub for all restaurant locations   <br> |              Chain management   <br> |

 --- 
## External systems   
|         System   <br> |                                           Integration Type   <br> |  Status   <br> |
|:----------------------|:------------------------------------------------------------------|:---------------|
|        **CRM**   <br> |     Customer data sync — create/update contacts from sales   <br> | Planned   <br> |
|   **Payments**   <br> |         Stripe, Square, PayPal payment gateway integration   <br> | Planned   <br> |
| **Accounting**   <br> |                QuickBooks, Xero invoice/transaction export   <br> | Planned   <br> |
|      **Email**   <br> |   Transactional emails — receipts, invoices, notifications   <br> | Planned   <br> |
|        **SMS**   <br> |                Order status updates, promotional messaging   <br> | Planned   <br> |

 --- 
## Integration boundaries   
- **Config cascade** — settings resolve site → admin → defaults before reaching an external service.   
- **Auth** — API tokens per integration; cloud endpoints use HTTPS + JWT.   
- **Sync** — Local service continuity is separated from cloud analytics (see `../architecture/sync-data.md`).   
 --- 
   
## Related Docs   
- → `custom-form.md` — Form builder for CRM data collection   
- → `../architecture/sync-data.md` — Synchronization boundaries   
- → `../plans/cloud.md` — Cloud operating model   
- → `../README.md` — Master index   
