---
# yaml-language-server: $schema=schemas/story.schema.json
Status: Published
Object type:
    - Story
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreigj6rfyper7krqy54qrqdcth36anukzwfg3dkcjvlbjageirv6eee
---
# Story — Founder Journey & Project Narrative   
> Type: Story 📖   
> Layout: Page   
> Description: Narrative record of how the project started and evolved — the founder's journey through technologies, products, packages, and platform decisions. Chronicles decisions, experiments, and lessons in chronological phases.   

## Properties   
|            Property   <br> |                  Type   <br> |                                                   Options   <br> |                        Description   <br> |
|:---------------------------|:-----------------------------|:-----------------------------------------------------------------|:------------------------------------------|
|            `Status`   <br> |                Select   <br> |                       Draft, Ongoing, Published, Archived   <br> |                    Narrative state   <br> |
|            `Author`   <br> |     Relation → Person   <br> |                                                         —   <br> |                Who tells the story   <br> |
|        `Start Date`   <br> |                  Date   <br> |                                                         —   <br> |     When the phase/narrative began   <br> |
|          `End Date`   <br> |                  Date   <br> |                                                         —   <br> |       When the narrative concluded   <br> |
|             `Phase`   <br> |                Select   <br> | Foundations, Experimentation, Platform, Suite, Enterprise   <br> |             Story chapter or phase   <br> |
|     `Related Goals`   <br> |       Relation → Goal   <br> |                                                         —   <br> |      Achievements this phase drove   <br> |
|     `Related Plans`   <br> |       Relation → Plan   <br> |                                                         —   <br> |          Plans this phase informed   <br> |
|  `Related Products`   <br> |    Relation → Product   <br> |                                                         —   <br> |      Products born from this phase   <br> |
|  `Related Features`   <br> |    Relation → Feature   <br> |                                                         —   <br> | Capabilities created along the way   <br> |
| `Related Decisions`   <br> |   Relation → Decision   <br> |                                                         —   <br> |               Key choices recorded   <br> |
|              `Tags`   <br> |          Multi-select   <br> |                                                         —   <br> |               Cross-cutting labels   <br> |

## Usage in Knowledge Graph   
|          Relation   <br> |   Target   <br> |
|:-------------------------|:----------------|
|            Author   <br> |   Person   <br> |
|     Related Goals   <br> |     Goal   <br> |
|     Related Plans   <br> |     Plan   <br> |
|  Related Products   <br> |  Product   <br> |
|  Related Features   <br> |  Feature   <br> |
| Related Decisions   <br> | Decision   <br> |

## Related   
- → `\_object-types.md` — All type definitions   
- → `\_relations.md` — Relations guide   
- → `note.md` — Note type (for informal captures)   
- → `../stories/\_index.md` — Stories directory   
- → `../goals/achievement-board.md` — Achievement board   
- → `../plans/startup-planner.md` — Startup planning   
[Story — Founder Journey &amp; Project Narrative](story-founder-journey-and-project-narrative.md)    
