---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-05-08T08:05:16Z"
Created by:
    - mammhoud
id: bafyreia7spdbyzx5fnxgrjzkbpgcdojffo3f6jhadm5xugnncabsdhla4y
---
# Katmandu   
[Katmandu](katmandu.md)    
