---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Published
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-09T21:41:38Z"
id: bafyreigoxjvpcbzjlrwmi3ngwbcx6bzjzi46ff4um7gqqcmmlxc42dda3a
---
# Development Team Plans   
> Scope: All engineering plans across Structa Cloud products   
> Updated: 2026-09-06   

 --- 
## Active vertical slices (priority order)   
### 1. Formint Edition Chain — P0   
**Owner:** Formint team
**Path:** projects/formints/   
|      Edition   <br> |      Status   <br> |                  Next Gate   <br> |
|:--------------------|:-------------------|:----------------------------------|
|    Community   <br> |    Complete   <br> |                          —   <br> |
|     Standard   <br> |    Complete   <br> |                          —   <br> |
| Professional   <br> | In Progress   <br> | Backend sync and invoicing   <br> |
|        Cloud   <br> |     Planned   <br> |          Multi-tenant SaaS   <br> |
|       Client   <br> |    Complete   <br> |      Cloud API integration   <br> |

**Key Plans:**   
- `docs/plans/editions/10-formint-audit-and-reconciliation-2026-08-22.md` — Cross-edition audit   
- `docs/plans/django-fusion/django-fusion-tasks-mcp-plan.md` — Unified task API, MCP tooling   
- `docs/plans/django-fusion/config-cascade-plan.md` — Config cascade (active, baseline implemented)   
   
### 2. Precis Landing — P0   
**Canonical:** `docs/plans/precis-landing.md`
**Owner:** Precis team
**Path:** `projects/precis/precis-landing/`
**Contract:** Post-only code-rendering (server HTML / HTMX fragment / JSON for Astro)
**Verification:** `make backend-test` + `npm run check`   
### 3. Precis LMS (unified) — P1   
**Canonical:** `projects/precis/precis-main/` (merged LMS + Landing)
**Owner:** Precis team
**Dispatcher:** `WEBSITE=precis-main` (aliases: `precis-lms`, `precis-landing`)
**Key Areas:** Frontend build, deployment gates, Wagtail CMS integration   
### 4. CTC Research — Active   
**Canonical:** `docs/plans/repository/ctc-research-publish-2026-08-18.md`
**Owner:** CTC team
**Path:** `projects/precis/precis-ctc/`
**Workstreams:** Content/component audit, multi-lang catalogs (es/sv/pt-br), media proxy, email parity, `make redeploy`, cross-module workflows   
### 5. Syntara (Cypercloud) — Active   
**Canonical:** `projects/syntara/`
**Owner:** AI team
**Runtime alias:** `cypercloud` preserved for external contracts
**Stack:** Django + Webpack + HTMX + Monaco Editor + Ollama/OpenAI/Claude/Gemini   
### 6. Loop-CRM — Active (merge complete at feature level)   
**Canonical:** `docs/plans/loop-crm/merge-plan.md`
**Owner:** CRM team
**Path:** `projects/loop-crm/`
**Status:** Merge milestones shipped end-to-end (tenancy/auth → tenant-scoped CRUD → channels/adapters → allauth → finance ledger → AI hub → en/ar locale → billing/Wagtail landing). Remaining gates are operational, not feature code: live OAuth provider credentials, realtime/WebSocket hardening on the deployed stack, and the demo-state server-half verification.
**Milestones:** Tenancy/auth → tenant-scoped CRUD → channels/adapters → allauth → finance/POS ingestion → AI hub + locale → billing/landing   
### 7. django-fusion (Shared Framework) — P2   
**Canonical:** `docs/plans/django-fusion/`
**Owner:** Framework team
**Path:** `libs/django-fusion/`
**Active Plans:**   
- Tasks & MCP: unified background task API, Celery removal, MCP tooling   
- LLM & AI MCP Enhancement: provider-neutral routing, model levels, caching, streaming   
- Webpack Enhancement: project-customizable webpack, env configs   
- Analyzer + Skeleton + Asset APIs: dynamic skeletons, per-page components, Astro bridge   
 --- 
   
## ✅ Implementation status truth (backend × frontend) — 2026-09-06   
> Reconciliation pass run 2026-09-06 across the Django products. "Implemented"   
> means code-backed in the current tree; "Not yet" is planned/missing;   
> "Couldn't add" records work intentionally deferred or blocked. Cross-product   
> component evidence lives in   
> docs/audit/frontend-components-2026-09-06.md.   

|                                   Product   <br> |                                                                                                                                                                                                                                                                       Backend — implemented   <br> |                                                                                                                                 Backend — not yet / couldn't add   <br> |                                                                                                                                                                                                        Frontend — implemented   <br> |                                                                                                                           Frontend — not yet / flagged   <br> |
|:-------------------------------------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                              **Loop-CRM**   <br> | Tenancy+RBAC, CRM pipeline/deals/board, marketing posts + 12-platform catalog connectors + OAuth (incl. Google/Meta/TikTok/Reddit), attribution, finance/POS ledger, billing/Stripe, Wagtail landing road, workflows, Dramatiq tasks, realtime events, AI Hub (consent-gated), en/ar locale   <br> | Live OAuth credentials + publish E2E on deployed stack; realtime/WebSocket hardening on deploy; demo-state server-half verify (all need a real deploy, not code)   <br> |   Astro shell, RevOps dashboard, PipelineBoard (real `/apis/core/` data, GSAP drag, CSRF move), AiHub, CommandPalette, LocaleSwitcher, EmployeeDirectory, BillingPlan, ReportCatalog, Task Center — no placeholder components   <br> |             `PipelineDemo` is an inert marketing demo island (fake deals) — landing-preview only, not app code; live-provider config remains env-gated   <br> |
|              **Precis LMS (precis-main)**   <br> |                                                                                                                                                                                                                                 Wagtail content/pages + LMS backend + django-fusion routing   <br> |                                                                                                              Deployment/CI gates per plan; builder/data surfaces   <br> |                                                                                                                                                                                                 Astro/marketing shell shipped   <br> |                                  `frontend/src/lib/brand.ts` carries a stale "CRM + social scheduling · coming soon" tagline — flagged copy, see audit   <br> |
|                        **Precis Landing**   <br> |                                                                                                                                                                                                                                               Render-first Django contract (HTML/HTMX/JSON)   <br> |                                                                                                                                                                —   <br> |                                                                                                                                                                                                          Astro front-end live   <br> |                                                                                                                                                      —   <br> |
|                          **CTC Research**   <br> |                                                                                                                                                                                                         Multi-lang catalogs (es/sv/pt-br), media proxy, i18n fixtures, containerized deploy   <br> |                                                                                                 Publish gates (email parity E2E, redeploy validation) still open   <br> |                                                                                                                                                                                                   Backend-rendered pages live   <br> |   `blog/\*-details\*.html` demo templates still carry hard-coded Lorem-ipsum/2018 theme markup — not view-referenced, should be removed or quarantined   <br> |
|                  **Syntara (Cypercloud)**   <br> |                                                                                                                                                                                                                            Django `chat` app, config cascade, model routing, token tracking   <br> |                                                                                                     Provider keys + OAuth for live AI calls (local Ollama works)   <br> |                                                                                                                                                                                      Webpack/HTMX + Monaco customizer shipped   <br> |                                                                                                                                                      —   <br> |
|                           **Formint Pro**   <br> |                                                                                                                                                                                                                                  Django `server/` backend + sync; finance ledger groundwork   <br> |                                                                                                    Invoicing/reports APIs, client onboarding funnel (next gates)   <br> |                                                                          Astro + Vue shells shipped; create/edit modals + delete wired for suppliers, HR roles, schedules, payroll, admin notes, kitchen recipes (2026-09-06)   <br> |                                                                                                                                                      —   <br> |
|                         **Formint Cloud**   <br> |                                                                                                                                                                                                                                Django `backend/` (core/domain/handlers) + Channels API road   <br> |                                                                                                                  Multi-tenant SaaS, KDS, realtime sync scale-out   <br> |                                                                                                                                                                                                Astro frontend + shared client   <br> |                                                                                                                                                      —   <br> |
| **Formint Community / Standard / Client**   <br> |                                                                                                                                                                                                                                        SQLite/Rust (Community/Standard), Vue+Tauri (Client)   <br> |                                                                                                                             — (Cloud API integration for Client)   <br> |                                                                                                                                                                                                              Rust/Tauri + Vue   <br> |                                                                                                                                                      —   <br> |
|                         **django-fusion**   <br> |                                                                                                                                                                                                                                         Component/fragment/task/config systems; bolt bridge   <br> |                                                                                                    Celery removal + MCP tooling + LLM routing consolidation (P2)   <br> |                                                                                                                                                                                        Astro bridge + skeleton APIs in flight   <br> |                                                                                                                                                      —   <br> |

**What couldn't be added (deferred or blocked, with reason):**   
- **Loop-CRM live provider publishing** — connectors + OAuth exist and are tested, but no real provider credentials are configured anywhere; verification requires the deployed stack (`crm.structa.cloud`) and secrets. Not a code gap.   
- **Loop-CRM realtime on deploy** — Channels/SSE path is dev-verified; production Redis/channel-layer hardening is a deploy gate.   
- **CTC publish gates** — content/component audit + i18n + media proxy shipped; email parity + `make redeploy` validation remain deploy-blocked.   
- ~~Formint Pro create forms~~ — resolved 2026-09-06: suppliers, HR roles/schedules/payroll, admin notes and kitchen recipes/ingredients now open real create/edit modals wired to the Django server API (see `[docs/audit/frontend-components-2026-09-06.md](/Users/mammhoud/Documents/structa.cloud/docs/audit/frontend-components-2026-09-06.md)` § 2.3).   
- **ERD PNGs for Loop-CRM** — tooling added (2026-09-06); DOT graphs generated and PNGs rendered after installing `graphviz` locally. PNGs stay git-ignored derived assets (repo convention); the committed contract is the `docs/erd` README + DOT. Formint-cloud re-render remains blocked in this sandbox by the missing optional `django\_bolt` package (present in its Docker image).---   
   
## 🧱 Backend delivery workstreams (merged from backend-plans.md, 2026-09-10)   
### Formint invoicing & reports — P1   
|                                        Task   <br> |      Target Editions   <br> |  Status   <br> |
|:---------------------------------------------------|:----------------------------|:---------------|
|         Invoicing API — wizard form backend   <br> |           Pro, Cloud   <br> | Planned   <br> |
|             Invoice editing and choices API   <br> |           Pro, Cloud   <br> | Planned   <br> |
|         Reports API — sales, tax, inventory   <br> |           Pro, Cloud   <br> | Planned   <br> |
|                Unified theme attributes API   <br> |         All editions   <br> | Planned   <br> |
|         Cross-team data change coordination   <br> |         All editions   <br> | Planned   <br> |
|                Client onboarding funnel API   <br> | Standard, Pro, Cloud   <br> | Planned   <br> |
| Payment gateway integration (Stripe/PayPal)   <br> |           Pro, Cloud   <br> | Planned   <br> |

### Precis LMS backend gates — P1   
Contact collection backend, workspace provisioning + billing, and AI design-chat token metering are the open LMS backend deliverables (see truth table above).   
### Recurring delivery cadence   
|                              Review   <br> |   Cadence   <br> |              Team   <br> |
|:-------------------------------------------|:-----------------|:-------------------------|
|                 API contract review   <br> |    Weekly   <br> |           Backend   <br> |
|           Database migration review   <br> |    Weekly   <br> |           Backend   <br> |
| Schema backward-compatibility check   <br> | Bi-weekly   <br> |           Backend   <br> |
|        Performance and query review   <br> | Bi-weekly   <br> |           Backend   <br> |
|           Security dependency audit   <br> |    Weekly   <br> |       Engineering   <br> |
|       Cross-team data impact review   <br> |   Monthly   <br> | Backend + Product   <br> |

 --- 
## 🔧 Key Commands by Product   
|           Product   <br> |                                                      Check   <br> |                Test   <br> |        Build/Run   <br> |
|:-------------------------|:------------------------------------------------------------------|:---------------------------|:------------------------|
|       Formint Pro   <br> |           `cd projects/formints/formint-pro && make check`   <br> |         `make test`   <br> |   `make run-dev`   <br> |
|     Formint Cloud   <br> |         `cd projects/formints/formint-cloud && make check`   <br> |         `make test`   <br> |   `make run-dev`   <br> |
| Formint Community   <br> | `cd projects/formints/formint-community && pnpm run check`   <br> |         `pnpm test`   <br> | `pnpm tauri dev`   <br> |
|       Precis Main   <br> |     `cd projects/precis/precis-main/backend && make check`   <br> |         `make test`   <br> |   `make run-dev`   <br> |
|    Precis Landing   <br> |          `cd projects/precis/precis-landing && make check`   <br> | `make backend-test`   <br> |     `make build`   <br> |
|        Precis CTC   <br> |              `cd projects/precis/precis-ctc && make check`   <br> |         `make test`   <br> |     `make build`   <br> |
|           Syntara   <br> |                        `cd projects/syntara && make check`   <br> |         `make test`   <br> |       `make dev`   <br> |
|     django-fusion   <br> |                   `cd libs/django-fusion && uv run pytest`   <br> |                   —   <br> |                —   <br> |

 --- 
## 📐 Architecture Patterns (Reference)   
|              Pattern   <br> |                        Location   <br> |                                     Description   <br> |
|:----------------------------|:---------------------------------------|:-------------------------------------------------------|
|   **Dual rendering**   <br> |         Precis Landing, Formint   <br> | Server HTML / HTMX fragment / JSON API contract   <br> |
|   **Config cascade**   <br> | `django\_fusion.config.project`   <br> |           Layered YAML: site → admin → defaults   <br> |
| **Component system**   <br> |           `django\_fusion.comp`   <br> |       `{% comp "name" %}` registered components   <br> |
| **Fragment routing**   <br> |         `django\_fusion.routes`   <br> |         Named fragment endpoints for HTMX/Astro   <br> |
| **Background tasks**   <br> |          `django\_fusion.tasks`   <br> |             Dramatiq-based, Redis broker (prod)   <br> |
|    **Wagtail pages**   <br> |             Product `models.py`   <br> |              StreamField + django-fusion blocks   <br> |

 --- 
## 📋 Current Engineering Priorities (from recommendations.md)   
| Priority   <br> |                                                                         Action   <br> |                        Verification   <br> |
|:----------------|:--------------------------------------------------------------------------------------|:-------------------------------------------|
|       P0   <br> |                         Formint edition extension chain — next executable task   <br> |              Edition-specific tests   <br> |
|       P0   <br> |                      Precis Landing content work — preserve rendering contract   <br> |     Backend tests + `npm run check`   <br> |
|       P1   <br> |                                   Precis LMS — close frontend/deployment gates   <br> |          Site checks, tests, builds   <br> |
|       P1   <br> |            Repository cleanup — don't delete compatibility sources prematurely   <br> |                      Reference scan   <br> |
|       P2   <br> |   django-fusion tasks & MCP — unified bg task API, Celery removal, MCP tooling   <br> | `uv run pytest libs/django-fusion/`   <br> |
|       P2   <br> |                          Docs maintenance — link validation, stale ref removal   <br> |                        Link checker   <br> |

 --- 
## 🔗 Cross-References   
- **Plan Registry:** `docs/plans/README.md` — all active/superseded plans   
- **Recommendations:** `docs/recommendations.md` — prioritized next actions   
- **Project Awareness:** `docs/guides/00-project-awareness.md` — object graph, commands   
- **Architecture:** `docs/ARCHITECTURE.md` — full system architecture   
- **Config Cascade:** `docs/plans/django-fusion/config-cascade-plan.md`   
- **Marketing Claims:** `docs/plans/marketing-claims.md` — evidence requirements for feature claims   
 --- 
   
## Remarks & Notes   
- Use `projects/Makefile` dispatcher (`make check WEBSITE=<target>`) for canonical commands   
- Product `AGENTS.md` files are the local source of truth for conventions   
- Do not create plans in `docs/dev/plans/`, `projects/\*/docs/`, or `docs/plans/migrated/`   
- Completed plans are deleted once superseded; git history is the archive   
 --- 
   
## 🇸🇦 ملخّص عربي — خطط فريق التطوير   
> النطاق: كل خطط هندسة المنتجات عبر Structa Cloud، مرتّبة بالأولوية.   

### سلاسل المنتجات النشطة   
|                                                                  المنتج   <br> |                                                                                    الحالة   <br> |                                                                                                                         البوابة التالية   <br> |
|:-------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------|
|                                                   سلسلة إصدارات Formint   <br> |                                           المجتمع والقياسي والعميل مكتملة؛ الاحترافي جارٍ   <br> |                                                                                                         مزامنة الواجهة الخلفية والفوترة   <br> |
|                             Precis الموحّد (نظام التعلّم + صفحة الهبوط)   <br> |                                                                                       نشط   <br> |                                                                                                                    بوابات النشر والبناء   <br> |
|                                                          Precis Landing   <br> |                                                               موقع حيّ (نسخة قديمة تُخدم)   <br> |                                                                                                                         عمل محتوى مستمر   <br> |
|                                                         مركز CTC البحثي   <br> |                                                                                       نشط   <br> |                                                                                                بوابات النشر: تكافؤ البريد والنشر المعاد   <br> |
|                                                    Syntara (Cypercloud)   <br> |                                                                                       نشط   <br> |                                                                                            مفاتيح مزوّدي الذكاء الاصطناعي للاتصال الحيّ   <br> |
|                                                                Loop-CRM   <br> |                                                                   اكتمل على مستوى الميزات   <br> |                                                            بوابات تشغيلية: بيانات مزوّدي OAuth الحيّة، والتحقق من حالة العرض على الخادم   <br> |
|                                          django-fusion (الإطار المشترك)   <br> |                                                                                       نشط   <br> |                                                                                                        تكامل المهام وMCP وتوحيد التوجيه   <br> |

### جدول الحقيقة (2026-09-06)   
- "منفَّذ" يعني مدعوماً بالكود في الشجرة الحالية؛ "ليس بعد" مخطط أو ناقص؛
و"تعذّر الإضافة" يسجّل العمل المؤجَّل عمداً أو المعطول مع السبب.   
- البنود المفتوحة الرئيسية: بيانات اعتماد OAuth الحيّة لـ Loop-CRM (تحتاج
نشراً حقيقياً)، تحصين الوقت الفعلي عند النشر، بوابات نشر CTC، وبوابات النشر
والبناء لـ Precis.   
   
### أعمال الواجهة الخلفية (بعد دمج backend-plans.md في 2026-09-10)   
- فوترة وفواتير Formint (احترافي/سحابي): API الفواتير والتحرير والتقارير —
مخطط له.   
- بوابات نظام التعلّم Precis: جمع جهات الاتصال، وتجهيز مساحات العمل مع
الفوترة، وقياس توكن المحادثة — ليس بعد.   
- إيقاع المراجعة الأسبوعي: عقود API، ومراجعات الترحيل، وتدقيق الأمان.   
   
> المصدر الرسمي لسجل الخطط: docs/plans/README.md — لا تخترع حالة الخطة هنا.   

