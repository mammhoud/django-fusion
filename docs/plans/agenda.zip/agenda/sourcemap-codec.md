---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-08-08T06:41:31Z"
Created by:
    - mammhoud
id: bafyreia2zq2lrzzvnsymsg4knwpzft7jl3mc7b4c3mkhnqoa5xkpgqsazy
---
# sourcemap-codec   
[sourcemap-codec](sourcemap-codec.md)    
