---
# yaml-language-server: $schema=schemas/workspace.schema.json
Status: Published
Object type:
    - Workspace
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreiac74ehtcrahos5c5gqifxcbjkllzoaitt4rz6ikuvvbsvsmy7ulu
---
# Domains   
As a startup, it is important to optimize your resource allocation in order to make the most of your limited resources. One way to do this is to focus on your core competencies and outsource or partner for everything else.   
### Manpower   
- Human resources or workforce required to execute various tasks and responsibilities within your startup.   
   
### Technology   
- Tools, software, hardware, and infrastructure needed to support your startup's operations and processes.   
   
### Finances   
- Collaborating with external entities such as suppliers, vendors, service providers, distributors, and strategic allies to enhance your startup's capabilities and reach.   
   
### Partnerships   
- Capital, funding, and financial resources needed to launch, operate, and grow your startup.   
   
### Budget   
## Related Docs — (intentionally omitted: legacy startup template — see startup-planner.md or resource-plan.md.)   
