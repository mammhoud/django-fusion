---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-08-05T23:12:29Z"
Created by:
    - mammhoud
id: bafyreia24wfe2263wwwvrw64xfgtnaoczo2nwovxkprm5gt2pu5fjsgtra
---
# dep-lib-powerfmt   
[dep-lib-powerfmt](dep-lib-powerfmt.md)    
