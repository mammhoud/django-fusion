---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Planned
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreigondw3eghopagvhdmkujpfr5uju7twf2a3zfk224sw2jpnocsc7q
---
# Marketing Campaigns   
> Description: Repeatable campaign method connecting product value to a defined audience, message, channel, offer, and measurable outcome.   

## Campaign brief   
|    Field   <br> |                                                   Definition   <br> |
|:----------------|:--------------------------------------------------------------------|
|  Product   <br> |                                  Product or edition promoted   <br> |
| Audience   <br> |                          Segment, country, role, and problem   <br> |
|  Message   <br> |             Specific customer benefit, not a technology list   <br> |
|    Proof   <br> |         Pilot, workflow, documentation, or measured evidence   <br> |
|  Channel   <br> | Website, search, email, social, community, partner, or event   <br> |
|    Offer   <br> |          Demo, trial, guide, pilot, license, or subscription   <br> |
|      KPI   <br> |   Qualified leads, demos, activation, conversion, or revenue   <br> |
|    Owner   <br> |                                  Accountable team and person   <br> |

## Formint campaign themes   
1. **Keep serving:** offline continuity for connectivity-sensitive restaurants.   
2. **Kitchen clarity:** KDS, station routing, notes, modifiers, and preparation visibility.   
3. **Arabic-first operations:** bilingual menus, RTL workflows, and local presentation.   
4. **Grow without a forced migration:** local Professional operations with an optional cloud path.   
5. **Restaurant depth:** combos, extras, recipes, inventory, loyalty, and branch control.   
   
## Campaign workflow   
Research → brief → message/proof review → landing page/content → demo or trial → qualification → sales handoff → measurement → retrospective.   
## Marketing guardrails   
Use the approved claims register. State whether a capability is planned, piloted, or released. Do not claim regulatory compliance, market leadership, guaranteed uptime, or numerical performance without evidence.   
## Related   
- → `project-workspace.md` — Workspace hub   
- → `marketing-strategy.md` — Overall strategy   
- → `sales.md` — Sales handoff   
- → `social-networks.md` — Social channels   
- → `../products/formint-pos.md` — Product description   
- → `../objects/product.md` — Product object   
- → `../../../plans/marketing-claims.md` — Evidence-based claims register   
[Marketing Campaigns](marketing-campaigns.md)    
