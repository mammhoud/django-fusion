---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-08-09T21:46:37Z"
Created by:
    - mammhoud
id: bafyreiextgupnutqkwyjodmzhltmzqr4sdhkjrimtz2kxiqtenlisd243y
---
# sharp-libvips-darwin-x64   
[sharp-libvips-darwin-x64](sharp-libvips-darwin-x64.md)    
