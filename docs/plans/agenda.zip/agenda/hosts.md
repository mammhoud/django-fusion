---
# yaml-language-server: $schema=schemas/workspace.schema.json
Status: Active
Object type:
    - Workspace
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreiap5erme4ham4mhmgod66nqf24bzf7736gm2254z3hijazfrudonq
---
# Hosts   
> Description: A navigable hub that groups projects, products, plans, teams, campaigns, channels, research, and delivery evidence around a shared purpose.   

## Properties   
|           Property   <br> |                         Type   <br> |                                     Description   <br> |
|:--------------------------|:------------------------------------|:-------------------------------------------------------|
|           `Status`   <br> |                       Select   <br> |                        Active, Paused, Archived   <br> |
|          `Purpose`   <br> |                         Text   <br> |                       Why this workspace exists   <br> |
|        `Backlinks`   <br> |                         Text   <br> |                   Documents linking to this hub   <br> |
| `Related Projects`   <br> |           Relation → Project   <br> |                 Initiatives and repository work   <br> |
| `Related Products`   <br> |           Relation → Product   <br> |                        Customer-facing products   <br> |
|    `Related Plans`   <br> |              Relation → Plan   <br> | Roadmaps, campaigns, sales, and operating plans   <br> |
|    `Related Teams`   <br> |              Relation → Team   <br> |                         Owners and contributors   <br> |
| `Related Research`   <br> |   Relation → Market Research   <br> |                          Evidence and discovery   <br> |
| `Related Channels`   <br> |       Relation → Integration   <br> |   Social, community, sales, or partner channels   <br> |
|             `Tags`   <br> |                 Multi-select   <br> |                   Workspace and business labels   <br> |

## Use   
Create one Workspace for a portfolio or major initiative. Use Project for a bounded initiative, Product for an offering, Plan for a time-bound or operational method, and Team for collective ownership.   
## Graph   
|     Path   <br> |                                                                                                                             Flow   <br> |
|:----------------|:----------------------------------------------------------------------------------------------------------------------------------------|
| Products   <br> |                 Workspace → Project → Product → Edition → Feature; Product → Campaign → Channel, Sales → Commerce, Team → Person   <br> |
| Delivery   <br> |                                                                                Workspace → Research → Goals → Milestones → Tasks   <br> |

## Related   
- → `\_object-types.md` — Type definitions   
- → `\_relations.md` — Relation guide   
- → `../plans/project-workspace.md` — Portfolio workspace   
- → `../objects/product.md` — Product object   
- → `../objects/team.md` — Team object   
- → `../plans/product-development.md` — Development lifecycle   
[Hosts](hosts.md)    
