---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-08-12T11:43:24Z"
Created by:
    - mammhoud
id: bafyreigyixfp4vhdbsrzlvarfefblnmzdmwx3cydrje3fc4n7fuvgk3t5y
---
# vscode-uri   
[vscode-uri](vscode-uri.md)    
