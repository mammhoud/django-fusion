---
# yaml-language-server: $schema=schemas/feature.schema.json
Object type:
    - Feature
Status: Planned
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreihqmldltptifhopdntq5oa6bdzfwbtk2xuwaekaf5wo3fmkzic7bu
---
# Custom Form — Dynamic Form Builder   
> Type: Feature ✨   
> Description: A flexible form builder for creating custom input forms — feedback, surveys, registrations, and data collection — integrated with the CRM system.   

 --- 
## Overview   
The Custom Form feature enables administrators to:   
- **Build custom forms** without coding — drag-and-drop field configuration   
- **Collect structured data** from customers, employees, and site visitors   
- **Integrate with CRM** — form submissions feed directly into customer records   
- **Embed anywhere** — forms can be placed on any page via Wagtail snippets   
 --- 
   
## Project Context   
|         Aspect   <br> |                                                                               Description   <br> |
|:----------------------|:-------------------------------------------------------------------------------------------------|
|      **Sites**   <br> |                                               All sites (CTC Research, LMS Demo, VResume)   <br> |
|      **Color**   <br> |   Violet (#8b5cf6) / Purple (#a855f7) — representing form interaction and data collection   <br> |
|   **CRM Link**   <br> |                                        Form submissions create/update CRM contact records   <br> |
| **Tech Stack**   <br> |                                    django-fusion component system, Wagtail snippets, HTMX   <br> |

 --- 
## Color Palette: Form Violet   
|   Token   <br> |                    Hex   <br> |                                Usage   <br> |
|:---------------|:------------------------------|:--------------------------------------------|
| Primary   <br> | `#8b5cf6` (Violet-500)   <br> | Submit buttons, active field borders   <br> |
| Surface   <br> |  `#f5f3ff` / `#2e1065`   <br> |        Form backgrounds (light/dark)   <br> |
|  Accent   <br> | `#a855f7` (Purple-500)   <br> |  Required field markers, helper text   <br> |
|   Error   <br> |    `#ef4444` (Red-500)   <br> |                    Validation errors   <br> |

 --- 
## Field Types   
- **Text Input** — Single-line text, email, URL, phone   
- **Text Area** — Multi-line text for comments, descriptions   
- **Select Dropdown** — Single and multi-select options   
- **Checkboxes / Radio** — Binary and multiple choice   
- **Date / Time** — Date picker, time selector   
- **File Upload** — Document, image, and media uploads   
- **Signature Pad** — Touch/click signature capture   
 --- 
   
## Related Docs   
- → `integrations.md` — CRM integration   
- → `../guides/development-workflow.md` — Adding form components   
- → `../tasks/tasks-and-backlog.md` — Implementation task   
- → `../README.md` — Master index   
[Custom Form — Dynamic Form Builder](custom-form-dynamic-form-builder.md)    
