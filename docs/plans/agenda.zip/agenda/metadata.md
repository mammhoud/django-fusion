---
# yaml-language-server: $schema=schemas/page.schema.json
Object type:
    - Page
Creation date: "2026-07-01T15:22:59Z"
Created by:
    - mammhoud
id: bafyreiejfiv3dci5mqfhaxrlein5hg6faejggnl2yieersqrh3feklwzmy
---
# METADATA   
[METADATA](metadata.md)    
