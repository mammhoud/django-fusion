---
# yaml-language-server: $schema=schemas/plan.schema.json
Status: Published
Object type:
    - Plan
Created by:
    - mammhoud
Creation date: "2026-09-03T15:18:28Z"
id: bafyreicgcg6bi5roab4olkzx2bop5lsansuv7t46kdixklnggmt7hdqmkm
---
# Data Analyst Plans   
> Scope: Metrics, analytics, evidence tracking, pilot validation, and data-driven decisions across Structa Cloud products   
> Updated: 2026-08-25   

 --- 
## Core responsibilities   
### 1. Evidence-backed claims validation   
**Source:** `docs/plans/marketing-claims.md`
**Rule:** Objective claims require evidence before publication   
|     Claim Level   <br> |                                      Meaning   <br> |                                            Publication Rule   <br> |
|:-----------------------|:----------------------------------------------------|:-------------------------------------------------------------------|
|      Capability   <br> | Product designed/implemented to do something   <br> | Say "supports"/"includes" only when release evidence exists   <br> |
|  Pilot Evidence   <br> |    Observed in named internal/customer pilot   <br> |                     Include scope, date, sample, limitation   <br> |
|  Measured Claim   <br> |    Reproducible benchmark/operational metric   <br> |          Include method, baseline, environment, review date   <br> |
| Regulated Claim   <br> |                     Compliance/legal outcome   <br> |                       Require local specialist/legal review   <br> |

### 2. Approved positioning language   
|               Claim   <br> |                             Audience   <br> |                          Evidence Required   <br> |                                                     Safe Wording Now   <br> |
|:---------------------------|:--------------------------------------------|:--------------------------------------------------|:----------------------------------------------------------------------------|
|        Arabic-first   <br> |            MENA restaurant operators   <br> |         RTL, translation, invoice UX tests   <br> |            "Designed for Arabic and bilingual restaurant workflows."   <br> |
|       Offline-first   <br> | Operators with unstable connectivity   <br> |         Offline/reconnect acceptance tests   <br> | "Continue core operations during interruptions and reconcile later."   <br> |
|                 KDS   <br> |                 Restaurant operators   <br> |            KDS workflow and pilot evidence   <br> |              "Route and prioritize kitchen tickets across stations."   <br> |
|        Multi-branch   <br> |                Chains and franchises   <br> | Branch permissions, publishing, sync tests   <br> |               "Manage branch operations from a shared control view."   <br> |
|             Loyalty   <br> |         Customer-focused restaurants   <br> |        Ledger, reversal, and consent tests   <br> |      "Build repeat-visit programs with an auditable rewards ledger."   <br> |
|          API access   <br> |              Partners and developers   <br> |   Versioned schema, auth, rate-limit tests   <br> |  "Integrate through a versioned API without direct database access."   <br> |
| Local-to-cloud path   <br> |                    Growing operators   <br> |                Migration and restore pilot   <br> |       "Start locally and move to managed cloud services when ready."   <br> |

### 3. Claims Requiring Evidence Before Use   
- "Guaranteed uptime" or numerical availability   
- "X% faster checkout/KDS/preparation"   
- "Fully compliant" with ZATCA, UAE FTA, VAT, or another regulator   
- "Saves X%" or "increases revenue/retention by X%"   
- "Market leader," "best," "only," or comparative competitor claims   
- "Production-ready" for a feature still marked planned or in migration   
- Pricing/margin promises not validated against support, hosting, payment, storage costs   
 --- 
   
## 📋 Evidence Record Template   
```
Claim:
Audience:
Release/version:
Evidence type: capability | pilot | measured | regulated
Source or test:
Sample/environment:
Limitations:
Owner:
Confidence:
Review date:
Approval:

```
 --- 
## 🔬 Analytics & Metrics Tracking   
### Product-Level Metrics   
|                  Product   <br> |                                                         Key Metrics   <br> |                       Data Source   <br> | Review Cadence   <br> |
|:--------------------------------|:---------------------------------------------------------------------------|:-----------------------------------------|:----------------------|
|    **Formint Community**   <br> |        Active installs, offline session duration, sync success rate   <br> | Local SQLite + telemetry (opt-in)   <br> |        Monthly   <br> |
| **Formint Professional**   <br> |        Restaurant count, terminal count, order volume, sync latency   <br> |       Django backend + PostgreSQL   <br> |         Weekly   <br> |
|        **Formint Cloud**   <br> |            Tenant count, terminal count, uptime, API latency, churn   <br> |         Django + Channels + Redis   <br> |          Daily   <br> |
|           **Precis LMS**   <br> |  Course enrollments, completion rates, active learners, cert issued   <br> |        Wagtail + Django analytics   <br> |         Weekly   <br> |
|       **Precis Landing**   <br> |            Catalog views, search conversion, SEO rankings, lead gen   <br> |      Astro + analytics middleware   <br> |         Weekly   <br> |
|         **CTC Research**   <br> |           Publication views, multi-lang engagement, media downloads   <br> |        Wagtail + custom analytics   <br> |        Monthly   <br> |
|              **Syntara**   <br> | Chat sessions, template customizations, provider usage, token costs   <br> |         Django + AI provider logs   <br> |         Weekly   <br> |
|             **Loop-CRM**   <br> |      Workspace count, contact records, campaign sends, social posts   <br> |   Django + Channels + social APIs   <br> |         Weekly   <br> |

### Cross-Product Metrics   
|                       Metric   <br> |                            Definition   <br> |            Products   <br> |               Target   <br> |
|:------------------------------------|:---------------------------------------------|:---------------------------|:----------------------------|
|  **Deployment success rate**   <br> |   Successful deploys / total attempts   <br> | All Django products   <br> |                  99%   <br> |
|            **Test coverage**   <br> | Lines covered / total lines (backend)   <br> | All Django products   <br> |                  80%   <br> |
|               **Build time**   <br> |                  CI pipeline duration   <br> |        All products   <br> |             < 10 min   <br> |
| **Security vulnerabilities**   <br> |    Critical/high CVEs in dependencies   <br> |        All products   <br> | 0 critical, < 5 high   <br> |
|  **Documentation freshness**   <br> |                Days since last update   <br> |            All docs   <br> |            < 30 days   <br> |

 --- 
## 📈 Pilot & Experiment Tracking   
### Active Pilots   
|                           Pilot   <br> |           Product   <br> | Start Date   <br> |                   Sample   <br> |      Status   <br> |        Owner   <br> |
|:---------------------------------------|:-------------------------|:------------------|:--------------------------------|:-------------------|:--------------------|
|    Offline-first reconciliation   <br> | Formint Community   <br> | 2026-07-15   <br> |            3 restaurants   <br> | In progress   <br> | Formint team   <br> |
|       KDS multi-station routing   <br> |       Formint Pro   <br> | 2026-08-01   <br> |     1 chain (5 stations)   <br> |     Planned   <br> | Formint team   <br> |
|           Arabic RTL invoice UX   <br> |     Formint Cloud   <br> | 2026-08-10   <br> |            2 MENA pilots   <br> |     Planned   <br> | Formint team   <br> |
|               Multi-branch sync   <br> |     Formint Cloud   <br> | 2026-08-20   <br> | 1 franchise (3 branches)   <br> |     Planned   <br> | Formint team   <br> |
| LMS course completion analytics   <br> |        Precis LMS   <br> | 2026-08-01   <br> |              All courses   <br> | In progress   <br> |  Precis team   <br> |
|       AI template customization   <br> |           Syntara   <br> | 2026-07-20   <br> |                 50 users   <br> | In progress   <br> |      AI team   <br> |

### Experiment Framework   
1. **Hypothesis:** Clear, measurable statement   
2. **Metric:** Primary + guardrail metrics defined upfront   
3. **Sample:** Power calculation, randomization method   
4. **Duration:** Fixed timeline with early-stop rules   
5. **Analysis:** Pre-registered analysis plan   
6. **Decision:** Ship / iterate / kill criteria   
 --- 
   
## 🔧 Data Infrastructure   
### Current Stack   
|             Layer   <br> |                     Technology   <br> |                              Products   <br> |
|:-------------------------|:--------------------------------------|:---------------------------------------------|
|    **Primary DB**   <br> |                  PostgreSQL 16   <br> |                   All Django products   <br> |
|   **Cache/Queue**   <br> |                          Redis   <br> | All Django products (Dramatiq broker)   <br> |
| **Local/Offline**   <br> |           SQLite (Diesel/Rust)   <br> |   Formint Community, Standard, Client   <br> |
|     **Analytics**   <br> | Custom Django models + Wagtail   <br> |        Precis, Formint Pro/Cloud, CTC   <br> |
|         **AI/ML**   <br> |     Ollama + OpenAI-compatible   <br> |                               Syntara   <br> |
|     **Export/BI**   <br> |         CSV/JSON API endpoints   <br> |                          All products   <br> |

### Data Access Patterns   
- **Real-time:** Django ORM, Channels WebSocket (Formint Cloud)   
- **Batch/Analytics:** Management commands, Dramatiq tasks   
- **Export:** REST API endpoints with versioned schemas   
- **Privacy:** Tenant-scoped queries, GDPR-compliant deletion   
 --- 
   
## 📋 Data Analyst Workflows   
### Weekly   
- [ ] Review pilot progress & evidence collection   
- [ ] Validate new claims against evidence register   
- [ ] Update metric dashboards (if applicable)   
- [ ] Sync with product leads on data needs   
### Per Release   
- [ ] Collect release evidence for capability claims   
- [ ] Run benchmark comparisons (baseline vs new)   
- [ ] Document limitations & confidence intervals   
- [ ] Update marketing-claims.md with new evidence   
### Quarterly   
- [ ] Full claims register review & re-approval   
- [ ] Pilot graduation / termination decisions   
- [ ] Metric target recalibration   
- [ ] Compliance evidence audit (ZATCA, VAT, etc.)   
 --- 
## 🔗 Cross-References   
- **Marketing Claims Register:** `docs/plans/marketing-claims.md` — authoritative claims & evidence   
- **Plan Registry:** `docs/plans/README.md` — all engineering plans with metrics gates   
- **Recommendations:** `docs/recommendations.md` — prioritized actions with verification   
- **Document Lifecycle:** `docs/plans/document-lifecycle.md` — status, ownership, archive policy   
- **Formint Editions:** `docs/plans/editions/README.md` — edition-specific metrics   
 --- 
   
## Remarks & Notes   
- Data analyst role spans product analytics, pilot validation, and marketing claim evidence   
- All evidence must be traceable to source (test, pilot, benchmark, regulatory review)   
- Arabic/English parity applies to metrics dashboards and reports   
- Coordinate with dev team for instrumentation & data pipeline changes   
- Privacy/GDPR: tenant isolation, consent tracking, right to deletion   
 --- 
   
## 🇸🇦 ملخّص عربي — خطط محلل البيانات   
> النطاق: المقاييس، والتحليلات، والتحقق من الأدلة، وتصديق التجارب   
> التجريبية، والقرارات المبنية على البيانات.   

### مستويات الأدلة وقاعدة النشر   
|                 المستوى   <br> |                                                          المعنى   <br> |                                                                         قاعدة النشر   <br> |
|:-------------------------------|:-----------------------------------------------------------------------|:-------------------------------------------------------------------------------------------|
|                    قدرة   <br> |                                  المنتج مصمم/منفَّذ ليفعل شيئاً   <br> |                                             قل "يدعم/يتضمن" فقط عند وجود دليل إصدار   <br> |
|              أدلة تجربة   <br> |                                 لوحظ في تجربة داخلية/عميل مسماة   <br> |                                                اذكر النطاق والتاريخ والعينة والحدود   <br> |
|              قياس منشور   <br> |                              معيار قابل للتكرار أو مقياس تشغيلي   <br> |                                        اذكر الطريقة والأساس والبيئة وتاريخ المراجعة   <br> |
|            ادعاء منظَّم   <br> |                                            نتيجة امتثال/قانونية   <br> |                                                        يلزم مراجعة مختص محلي/قانوني   <br> |

### المقاييس الرئيسية لكل منتج (الإيقاع)   
- **Formint احترافي:** عدد المطاعم والطرفيات وحجم الطلبات وزمن المزامنة — أسبوعي.   
- **Formint سحابي:** المستأجرون والجاهزية وزمن استجابة API والتسرّب — يومي.   
- **Precis نظام التعلّم:** التسجيلات ومعدلات الإكمال والمتعلّمون النشطون — أسبوعي.   
- **Loop-CRM:** مساحات العمل وجهات الاتصال والحملات والمنشورات — أسبوعي.   
- **عبر المنتجات:** نجاح النشر > 99%، وتغطية اختبارات > 80%، وصفر ثغرات حرجة.   
   
### ادعاءات تمنع قبل توفر الدليل   
ضمانات الجاهزية أو النِسب، و"أسرع بـ X%"، و"متوافق كلياً" مع الجهات التنظيمية،
و"الأفضل/الوحيد"، و"جاهز للإنتاج" لميزة مخططة، ووعود تسعير غير مدققة.   
> السجل الرسمي للادعاءات: docs/plans/marketing-claims.md — هذا الملف يعرّف   
> المستويات والصياغة الآمنة فقط.   

