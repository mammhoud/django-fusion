---
# yaml-language-server: $schema=schemas/pos_edition.schema.json
Status: In Development
Object type:
    - POS Edition
Created by:
    - mammhoud
Creation date: "2026-09-09T21:41:38Z"
id: bafyreibim7eq3zjeh7cuemmvoqhdvxp5qie7d6nqwkicwepmdvfnhlmpzm
---
# Formint Client — Shop & Employee Apps   
> Description: The separate client branch (projects/formints/formint-client/) — Vue 3 frontend over a Django shop backend (employee and shop applications), separate from the desktop edition chain.   

## Scope   
- Vue 3 frontend + Django shop backend   
- Employee apps, shop apps   
- Separate branch from the Community → Cloud chain   
   
## Boundaries   
- Not part of the Community → Standard → Pro → Cloud extension chain; it is its own branch   
- 🔵 Dev status (per d`ocs/plans/editions/ `chain status)   
   
## Evidence   
- 🔵 Dev (per d`ocs/plans/editions/ `chain status)   
- Plan: `../../../plans/editions/05-pos-client.md`   
   
## Related   
- → `formint-community.md` — Desktop chain root (separate branch)   
- → `../objects/edition.md` — Edition object type   
[Formint Client — Shop &amp; Employee Apps](formint-client-shop-and-employee-apps.md)    
